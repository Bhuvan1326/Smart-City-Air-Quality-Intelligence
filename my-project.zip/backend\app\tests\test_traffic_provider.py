"""Unit tests for app.services.traffic_provider. No DB dependency."""

import tempfile
from datetime import datetime

from app.core.config import settings
from app.services.traffic_provider import (
    TrafficDataSource,
    TrafficLevel,
    _demo_traffic_level,
    get_traffic_provider_status,
    get_traffic_reading,
    resolve_csv_path,
)


def _reset_csv_cache():
    import app.services.traffic_provider as mod

    mod._csv_cache = None
    mod._csv_cache_path = None


def test_morning_peak_is_high():
    assert _demo_traffic_level(datetime(2026, 1, 1, 8, 0)) == TrafficLevel.HIGH


def test_evening_peak_is_high():
    assert _demo_traffic_level(datetime(2026, 1, 1, 18, 30)) == TrafficLevel.HIGH


def test_night_hours_are_low():
    assert _demo_traffic_level(datetime(2026, 1, 1, 3, 0)) == TrafficLevel.LOW


def test_midday_is_moderate():
    assert _demo_traffic_level(datetime(2026, 1, 1, 13, 0)) == TrafficLevel.MODERATE


def test_demo_provider_never_labeled_live():
    original = settings.TRAFFIC_PROVIDER
    settings.TRAFFIC_PROVIDER = "demo"
    try:
        reading = get_traffic_reading(datetime(2026, 1, 1, 8, 0), ward_id="W01")
        assert reading.source == TrafficDataSource.DEMO
        assert "live" not in reading.note.lower() or "no live" in reading.note.lower()
    finally:
        settings.TRAFFIC_PROVIDER = original


def test_csv_provider_reads_matching_row():
    _reset_csv_cache()
    original_provider = settings.TRAFFIC_PROVIDER
    original_path = settings.TRAFFIC_CSV_PATH
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".csv", delete=False, newline=""
    ) as f:
        f.write("ward_id,hour,level\nW01,8,high\nW02,8,low\n")
        path = f.name

    try:
        settings.TRAFFIC_PROVIDER = "csv"
        settings.TRAFFIC_CSV_PATH = path
        _reset_csv_cache()
        reading = get_traffic_reading(datetime(2026, 1, 1, 8, 0), ward_id="W02")
        assert reading.source == TrafficDataSource.CSV
        assert reading.level == TrafficLevel.LOW
    finally:
        settings.TRAFFIC_PROVIDER = original_provider
        settings.TRAFFIC_CSV_PATH = original_path
        _reset_csv_cache()


def test_csv_provider_reports_unavailable_when_no_match():
    _reset_csv_cache()
    original_provider = settings.TRAFFIC_PROVIDER
    original_path = settings.TRAFFIC_CSV_PATH
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".csv", delete=False, newline=""
    ) as f:
        f.write("ward_id,hour,level\nW99,3,high\n")
        path = f.name

    try:
        settings.TRAFFIC_PROVIDER = "csv"
        settings.TRAFFIC_CSV_PATH = path
        _reset_csv_cache()
        reading = get_traffic_reading(datetime(2026, 1, 1, 8, 0), ward_id="W01")
        assert reading.source == TrafficDataSource.UNAVAILABLE
        assert reading.level is None
    finally:
        settings.TRAFFIC_PROVIDER = original_provider
        settings.TRAFFIC_CSV_PATH = original_path
        _reset_csv_cache()


def test_missing_csv_file_reports_unavailable():
    _reset_csv_cache()
    original_provider = settings.TRAFFIC_PROVIDER
    original_path = settings.TRAFFIC_CSV_PATH
    try:
        settings.TRAFFIC_PROVIDER = "csv"
        settings.TRAFFIC_CSV_PATH = "/nonexistent/path/traffic.csv"
        _reset_csv_cache()
        reading = get_traffic_reading(datetime(2026, 1, 1, 8, 0), ward_id="W01")
        assert reading.source == TrafficDataSource.UNAVAILABLE
        assert reading.level is None
    finally:
        settings.TRAFFIC_PROVIDER = original_provider
        settings.TRAFFIC_CSV_PATH = original_path
        _reset_csv_cache()


def test_default_provider_is_unavailable_not_demo():
    original = settings.TRAFFIC_PROVIDER
    settings.TRAFFIC_PROVIDER = ""
    try:
        reading = get_traffic_reading(datetime(2026, 1, 1, 8, 0), ward_id="W01")
        assert reading.source == TrafficDataSource.UNAVAILABLE
        assert reading.level is None
        assert "no traffic provider configured" in reading.note.lower()
    finally:
        settings.TRAFFIC_PROVIDER = original


def test_unrecognized_provider_is_unavailable_not_demo():
    original = settings.TRAFFIC_PROVIDER
    settings.TRAFFIC_PROVIDER = "some-future-live-provider"
    try:
        reading = get_traffic_reading(datetime(2026, 1, 1, 8, 0), ward_id="W01")
        assert reading.source == TrafficDataSource.UNAVAILABLE
        assert reading.level is None
    finally:
        settings.TRAFFIC_PROVIDER = original


def test_demo_provider_requires_explicit_opt_in():
    original = settings.TRAFFIC_PROVIDER
    settings.TRAFFIC_PROVIDER = "demo"
    try:
        reading = get_traffic_reading(datetime(2026, 1, 1, 8, 0), ward_id="W01")
        assert reading.source == TrafficDataSource.DEMO
        assert reading.level is not None
        assert "explicit" in reading.note.lower()
    finally:
        settings.TRAFFIC_PROVIDER = original


def test_status_reports_demo_when_provider_is_demo():
    original = settings.TRAFFIC_PROVIDER
    settings.TRAFFIC_PROVIDER = "demo"
    try:
        status = get_traffic_provider_status()
        assert status.configured is False
        assert "demo" in status.note.lower()
        assert "explicit" in status.note.lower()
    finally:
        settings.TRAFFIC_PROVIDER = original


def test_status_reports_not_configured_when_provider_unset():
    original = settings.TRAFFIC_PROVIDER
    settings.TRAFFIC_PROVIDER = ""
    try:
        status = get_traffic_provider_status()
        assert status.configured is False
        assert "not configured" in status.note.lower() or "unset" in status.note.lower()
    finally:
        settings.TRAFFIC_PROVIDER = original


def test_status_reports_not_configured_when_csv_path_is_blank():
    original_provider = settings.TRAFFIC_PROVIDER
    original_path = settings.TRAFFIC_CSV_PATH
    try:
        settings.TRAFFIC_PROVIDER = "csv"
        settings.TRAFFIC_CSV_PATH = ""
        status = get_traffic_provider_status()
        assert status.configured is False
        assert "TRAFFIC_CSV_PATH" in status.note
    finally:
        settings.TRAFFIC_PROVIDER = original_provider
        settings.TRAFFIC_CSV_PATH = original_path


def test_status_reports_unavailable_when_csv_file_missing():
    original_provider = settings.TRAFFIC_PROVIDER
    original_path = settings.TRAFFIC_CSV_PATH
    try:
        settings.TRAFFIC_PROVIDER = "csv"
        settings.TRAFFIC_CSV_PATH = "/nonexistent/path/traffic.csv"
        status = get_traffic_provider_status()
        assert status.configured is False
        assert "does not exist" in status.note
    finally:
        settings.TRAFFIC_PROVIDER = original_provider
        settings.TRAFFIC_CSV_PATH = original_path


def test_status_reports_unavailable_when_csv_missing_expected_columns():
    original_provider = settings.TRAFFIC_PROVIDER
    original_path = settings.TRAFFIC_CSV_PATH
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".csv", delete=False, newline=""
    ) as f:
        f.write("city,timestamp,congestion\nPune,2026-01-01T08:00,high\n")
        path = f.name

    try:
        settings.TRAFFIC_PROVIDER = "csv"
        settings.TRAFFIC_CSV_PATH = path
        status = get_traffic_provider_status()
        assert status.configured is False
        assert "missing" in status.note.lower()
    finally:
        settings.TRAFFIC_PROVIDER = original_provider
        settings.TRAFFIC_CSV_PATH = original_path


def test_status_reports_unavailable_when_csv_has_no_data_rows():
    original_provider = settings.TRAFFIC_PROVIDER
    original_path = settings.TRAFFIC_CSV_PATH
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".csv", delete=False, newline=""
    ) as f:
        f.write("ward_id,hour,level\n")
        path = f.name

    try:
        settings.TRAFFIC_PROVIDER = "csv"
        settings.TRAFFIC_CSV_PATH = path
        status = get_traffic_provider_status()
        assert status.configured is False
        assert "no data rows" in status.note.lower()
    finally:
        settings.TRAFFIC_PROVIDER = original_provider
        settings.TRAFFIC_CSV_PATH = original_path


def test_status_reports_configured_when_csv_is_valid():
    original_provider = settings.TRAFFIC_PROVIDER
    original_path = settings.TRAFFIC_CSV_PATH
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".csv", delete=False, newline=""
    ) as f:
        f.write("ward_id,hour,level\nW01,8,high\nW02,8,low\n")
        path = f.name

    try:
        settings.TRAFFIC_PROVIDER = "csv"
        settings.TRAFFIC_CSV_PATH = path
        status = get_traffic_provider_status()
        assert status.configured is True
        assert "csv" in status.note.lower()
    finally:
        settings.TRAFFIC_PROVIDER = original_provider
        settings.TRAFFIC_CSV_PATH = original_path


def test_status_does_not_trust_unrecognized_provider_value():
    original = settings.TRAFFIC_PROVIDER
    settings.TRAFFIC_PROVIDER = "some-future-live-provider"
    try:
        status = get_traffic_provider_status()
        assert status.configured is False
        assert "not a recognized value" in status.note
    finally:
        settings.TRAFFIC_PROVIDER = original


def test_resolve_csv_path_anchors_relative_paths_to_backend_dir():
    from app.core.config import BASE_DIR

    resolved = resolve_csv_path("data/traffic.csv")
    assert resolved == BASE_DIR / "data" / "traffic.csv"


def test_resolve_csv_path_leaves_absolute_paths_unchanged():
    resolved = resolve_csv_path("/tmp/traffic.csv")
    assert str(resolved) == "/tmp/traffic.csv"
