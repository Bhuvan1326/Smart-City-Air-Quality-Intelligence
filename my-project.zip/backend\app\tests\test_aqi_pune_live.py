from datetime import UTC, datetime
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from httpx import AsyncClient
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.civic_issue import WardAssignmentMethod
from app.models.monitoring import AQIReading, MonitoringStation
from app.services.aqi_providers import pune_stations
from app.services.civic_ward_assignment import WardAssignmentResult
from app.tests.test_helpers import make_db_session
from app.workers.tasks import aqi_ingestion

HADAPSAR_SPEC = next(
    s for s in pune_stations.REQUIRED_STATIONS if s.station_code == "PUNE_LIVE_HADAPSAR"
)


@pytest.fixture(autouse=True)
def _stub_ward_assignment():
    with patch(
        "app.services.civic_ward_assignment.assign_ward",
        new=AsyncMock(
            return_value=WardAssignmentResult(
                ward_id=None, method=WardAssignmentMethod.UNAVAILABLE
            )
        ),
    ):
        yield


def test_match_station_matches_on_name_and_provider():
    candidates = [
        {
            "id": 111,
            "name": "Hadapsar, Pune - IITM",
            "owner": {"name": "IITM"},
            "coordinates": {"latitude": 18.5089, "longitude": 73.9259},
        },
        {
            "id": 222,
            "name": "Some Other Place",
            "owner": {"name": "CPCB"},
            "coordinates": {"latitude": 18.51, "longitude": 73.90},
        },
    ]
    match = pune_stations.match_station(candidates, HADAPSAR_SPEC)
    assert match is not None
    assert match["id"] == 111


def test_match_station_rejects_name_match_far_from_expected_location():
    """A same-named station that's actually nowhere near the real Hadapsar
    (i.e. a namesake elsewhere) must not be matched by name alone."""
    candidates = [
        {
            "id": 999,
            "name": "Hadapsar",
            "owner": {"name": "IITM"},
            # ~500km away — well outside the sanity radius.
            "coordinates": {"latitude": 23.0, "longitude": 73.9259},
        }
    ]
    assert pune_stations.match_station(candidates, HADAPSAR_SPEC) is None


def test_match_station_returns_none_when_nothing_matches_name():
    candidates = [
        {
            "id": 1,
            "name": "Completely Unrelated Location",
            "owner": {"name": "CPCB"},
            "coordinates": {"latitude": 18.5089, "longitude": 73.9259},
        }
    ]
    assert pune_stations.match_station(candidates, HADAPSAR_SPEC) is None


def test_match_station_never_picks_nearest_when_name_disagrees():
    """Even a candidate sitting exactly on Hadapsar's coordinates must be
    rejected if its name doesn't correspond to Hadapsar at all — matching
    must never degrade into a bare nearest-station lookup."""
    candidates = [
        {
            "id": 5,
            "name": "Kothrud CAAQMS",
            "owner": {"name": "MPCB"},
            "coordinates": {"latitude": 18.5089, "longitude": 73.9259},
        }
    ]
    assert pune_stations.match_station(candidates, HADAPSAR_SPEC) is None


# ─── ingestion: one station at a time ───────────────────────────────────


@pytest.mark.asyncio
async def test_ingest_one_pune_station_resolves_and_inserts_first_time():
    session = make_db_session()

    # No existing station row.
    lookup_result = MagicMock()
    lookup_result.scalar_one_or_none.return_value = None
    latest_result = MagicMock()
    latest_result.scalar_one_or_none.return_value = None
    update_result = MagicMock()
    session.execute = AsyncMock(
        side_effect=[lookup_result, latest_result, update_result]
    )
    session.flush = AsyncMock()

    live = SimpleNamespace(
        pm25=68.2,
        pm10=110.0,
        no2=20.0,
        so2=5.0,
        co=1.0,
        o3=15.0,
        temperature=28.0,
        humidity=45.0,
        wind_speed=2.5,
        wind_direction=210.0,
        openaq_location_id=555,
        openaq_location_name="Hadapsar, Pune - IITM",
        distance_meters=0.0,
        observed_at=datetime.now(UTC),
    )
    candidates = [
        {
            "id": 555,
            "name": "Hadapsar, Pune - IITM",
            "owner": {"name": "IITM"},
            "coordinates": {"latitude": 18.5089, "longitude": 73.9259},
        }
    ]

    with (
        patch(
            "app.workers.tasks.aqi_ingestion.openaq.search_locations_near",
            new=AsyncMock(return_value=candidates),
        ),
        patch(
            "app.workers.tasks.aqi_ingestion.openaq.fetch_location_reading",
            new=AsyncMock(return_value=live),
        ),
    ):
        outcome = await aqi_ingestion._ingest_one_pune_station(session, HADAPSAR_SPEC)

    assert outcome == "inserted"
    session.add.assert_called()  # station row + reading row


@pytest.mark.asyncio
async def test_ensure_pune_station_row_assigns_real_ward_on_first_resolution():
    session = make_db_session()
    matched_location = {
        "id": 555,
        "name": "Hadapsar, Pune - IITM",
        "owner": {"name": "IITM"},
        "coordinates": {"latitude": 18.5089, "longitude": 73.9259},
    }

    with patch(
        "app.services.civic_ward_assignment.assign_ward",
        new=AsyncMock(
            return_value=WardAssignmentResult(
                ward_id="W03", method=WardAssignmentMethod.POINT_IN_POLYGON
            )
        ),
    ):
        station = await aqi_ingestion._ensure_pune_station_row(
            session, HADAPSAR_SPEC, matched_location, existing_station=None
        )

    assert station.ward_id == "W03"


@pytest.mark.asyncio
async def test_ensure_pune_station_row_backfills_ward_on_re_resolution():
    session = make_db_session()
    existing_station = SimpleNamespace(
        id="station-uuid",
        station_code=HADAPSAR_SPEC.station_code,
        name="Hadapsar",
        city="Pune",
        ward_id=None,
        latitude=18.0,
        longitude=73.0,
        openaq_location_id=999,
    )
    matched_location = {
        "id": 555,
        "name": "Hadapsar, Pune - IITM",
        "owner": {"name": "IITM"},
        "coordinates": {"latitude": 18.5089, "longitude": 73.9259},
    }

    with patch(
        "app.services.civic_ward_assignment.assign_ward",
        new=AsyncMock(
            return_value=WardAssignmentResult(
                ward_id="W03", method=WardAssignmentMethod.POINT_IN_POLYGON
            )
        ),
    ):
        station = await aqi_ingestion._ensure_pune_station_row(
            session, HADAPSAR_SPEC, matched_location, existing_station=existing_station
        )

    assert station.ward_id == "W03"


@pytest.mark.asyncio
async def test_ingest_one_pune_station_unresolved_when_no_openaq_match():
    session = make_db_session()
    lookup_result = MagicMock()
    lookup_result.scalar_one_or_none.return_value = None
    session.execute = AsyncMock(return_value=lookup_result)

    with patch(
        "app.workers.tasks.aqi_ingestion.openaq.search_locations_near",
        new=AsyncMock(return_value=[]),
    ):
        outcome = await aqi_ingestion._ingest_one_pune_station(session, HADAPSAR_SPEC)

    assert outcome == "unresolved_no_openaq_candidates"


@pytest.mark.asyncio
async def test_ingest_one_pune_station_no_fabrication_when_no_current_observation():
    """Station is already resolved, but OpenAQ currently has nothing for
    it — must report 'no_current_observation', never fabricate a reading."""
    session = make_db_session()
    existing_station = SimpleNamespace(
        id="station-uuid",
        station_code=HADAPSAR_SPEC.station_code,
        openaq_location_id=555,
        name="Hadapsar",
        latitude=18.5089,
        longitude=73.9259,
    )
    lookup_result = MagicMock()
    lookup_result.scalar_one_or_none.return_value = existing_station
    session.execute = AsyncMock(return_value=lookup_result)

    with patch(
        "app.workers.tasks.aqi_ingestion.openaq.fetch_location_reading",
        new=AsyncMock(return_value=None),
    ):
        outcome = await aqi_ingestion._ingest_one_pune_station(session, HADAPSAR_SPEC)

    assert outcome == "no_current_observation"
    session.add.assert_not_called()


@pytest.mark.asyncio
async def test_ingest_one_pune_station_accepts_reading_missing_pm25():
    """A station whose latest OpenAQ observation has no PM2.5 sensor but
    does have other pollutants (e.g. only PM10/NO2) must still be
    ingested — calculate_overall_aqi is designed to use whichever
    pollutants were actually measured, so requiring PM2.5 specifically
    would discard perfectly usable readings."""
    session = make_db_session()
    existing_station = SimpleNamespace(
        id="station-uuid",
        station_code=HADAPSAR_SPEC.station_code,
        openaq_location_id=555,
        name="Hadapsar",
        latitude=18.5089,
        longitude=73.9259,
    )
    lookup_result = MagicMock()
    lookup_result.scalar_one_or_none.return_value = existing_station
    latest_result = MagicMock()
    latest_result.scalar_one_or_none.return_value = None
    update_result = MagicMock()
    session.execute = AsyncMock(
        side_effect=[lookup_result, latest_result, update_result]
    )
    session.flush = AsyncMock()

    live = SimpleNamespace(
        pm25=None,
        pm10=110.0,
        no2=20.0,
        so2=None,
        co=None,
        o3=None,
        temperature=None,
        humidity=None,
        wind_speed=None,
        wind_direction=None,
        openaq_location_id=555,
        openaq_location_name="Hadapsar, Pune - IITM",
        distance_meters=0.0,
        observed_at=datetime.now(UTC),
    )

    with patch(
        "app.workers.tasks.aqi_ingestion.openaq.fetch_location_reading",
        new=AsyncMock(return_value=live),
    ):
        outcome = await aqi_ingestion._ingest_one_pune_station(session, HADAPSAR_SPEC)

    assert outcome == "inserted"
    session.add.assert_called()


@pytest.mark.asyncio
async def test_ingest_one_pune_station_rejects_reading_with_all_pollutants_none():
    """A LiveReading with every pollutant field None (no usable value at
    all) must still be treated as no_current_observation."""
    session = make_db_session()
    existing_station = SimpleNamespace(
        id="station-uuid",
        station_code=HADAPSAR_SPEC.station_code,
        openaq_location_id=555,
        name="Hadapsar",
        latitude=18.5089,
        longitude=73.9259,
    )
    lookup_result = MagicMock()
    lookup_result.scalar_one_or_none.return_value = existing_station
    session.execute = AsyncMock(return_value=lookup_result)

    live = SimpleNamespace(
        pm25=None,
        pm10=None,
        no2=None,
        so2=None,
        co=None,
        o3=None,
        temperature=None,
        humidity=None,
        wind_speed=None,
        wind_direction=None,
        openaq_location_id=555,
        openaq_location_name="Hadapsar, Pune - IITM",
        distance_meters=0.0,
        observed_at=datetime.now(UTC),
    )

    with patch(
        "app.workers.tasks.aqi_ingestion.openaq.fetch_location_reading",
        new=AsyncMock(return_value=live),
    ):
        outcome = await aqi_ingestion._ingest_one_pune_station(session, HADAPSAR_SPEC)

    assert outcome == "no_current_observation"
    session.add.assert_not_called()


@pytest.mark.asyncio
async def test_ingest_one_pune_station_skips_duplicate_observation():
    """Provider hasn't published anything newer than what's already
    stored -> no new row, but last_data_at still refreshes since the
    provider is still confirming the reading is current."""
    session = make_db_session()
    now = datetime.now(UTC)
    existing_station = SimpleNamespace(
        id="station-uuid",
        station_code=HADAPSAR_SPEC.station_code,
        openaq_location_id=555,
        name="Hadapsar",
        latitude=18.5089,
        longitude=73.9259,
    )
    lookup_result = MagicMock()
    lookup_result.scalar_one_or_none.return_value = existing_station
    latest_result = MagicMock()
    latest_result.scalar_one_or_none.return_value = now  # same timestamp as new obs
    update_result = MagicMock()
    session.execute = AsyncMock(
        side_effect=[lookup_result, latest_result, update_result]
    )

    live = SimpleNamespace(
        pm25=68.2,
        pm10=110.0,
        no2=20.0,
        so2=5.0,
        co=1.0,
        o3=15.0,
        temperature=28.0,
        humidity=45.0,
        wind_speed=2.5,
        wind_direction=210.0,
        openaq_location_id=555,
        openaq_location_name="Hadapsar",
        distance_meters=0.0,
        observed_at=now,
    )
    with patch(
        "app.workers.tasks.aqi_ingestion.openaq.fetch_location_reading",
        new=AsyncMock(return_value=live),
    ):
        outcome = await aqi_ingestion._ingest_one_pune_station(session, HADAPSAR_SPEC)

    assert outcome == "no_new_observation"
    session.add.assert_not_called()


@pytest.mark.asyncio
async def test_ingest_one_pune_station_newer_observation_replaces_stored():
    """OpenAQ returns a genuinely newer observation than whatever is
    currently stored -> a new reading row is inserted (the newer
    observation wins), and the station's last_data_at advances to the
    new provider timestamp."""
    session = make_db_session()
    existing_station = SimpleNamespace(
        id="station-uuid",
        station_code=HADAPSAR_SPEC.station_code,
        openaq_location_id=555,
        name="Hadapsar",
        latitude=18.5089,
        longitude=73.9259,
    )
    older_stored_ts = datetime(2026, 9, 8, 14, 30, tzinfo=UTC)
    newer_observed_ts = datetime(2026, 9, 12, 9, 0, tzinfo=UTC)

    lookup_result = MagicMock()
    lookup_result.scalar_one_or_none.return_value = existing_station
    latest_result = MagicMock()
    latest_result.scalar_one_or_none.return_value = older_stored_ts
    update_result = MagicMock()
    session.execute = AsyncMock(
        side_effect=[lookup_result, latest_result, update_result]
    )
    session.flush = AsyncMock()

    live = SimpleNamespace(
        pm25=95.0,
        pm10=120.0,
        no2=18.0,
        so2=4.0,
        co=0.8,
        o3=10.0,
        temperature=27.0,
        humidity=50.0,
        wind_speed=3.0,
        wind_direction=190.0,
        openaq_location_id=555,
        openaq_location_name="Hadapsar, Pune - IITM",
        distance_meters=0.0,
        observed_at=newer_observed_ts,
        is_stale=False,
        age_seconds=60.0,
    )
    with patch(
        "app.workers.tasks.aqi_ingestion.openaq.fetch_location_reading",
        new=AsyncMock(return_value=live),
    ):
        outcome = await aqi_ingestion._ingest_one_pune_station(session, HADAPSAR_SPEC)

    assert outcome == "inserted"
    session.add.assert_called_once()
    inserted_reading = session.add.call_args.args[0]
    assert inserted_reading.timestamp == newer_observed_ts
    assert inserted_reading.pm25 == 95.0


@pytest.mark.asyncio
async def test_ingest_one_pune_station_older_observation_cannot_replace_newer_stored():
    """OpenAQ returns an observation OLDER than what's already stored
    for this station (e.g. a transient provider blip returning a stale
    cached value) -> the older observation must never overwrite the
    newer one already on record. No new row is inserted."""
    session = make_db_session()
    existing_station = SimpleNamespace(
        id="station-uuid",
        station_code=HADAPSAR_SPEC.station_code,
        openaq_location_id=555,
        name="Hadapsar",
        latitude=18.5089,
        longitude=73.9259,
    )
    newer_stored_ts = datetime(2026, 9, 12, 9, 0, tzinfo=UTC)
    older_returned_ts = datetime(2026, 9, 8, 14, 30, tzinfo=UTC)

    lookup_result = MagicMock()
    lookup_result.scalar_one_or_none.return_value = existing_station
    latest_result = MagicMock()
    latest_result.scalar_one_or_none.return_value = newer_stored_ts
    update_result = MagicMock()
    session.execute = AsyncMock(
        side_effect=[lookup_result, latest_result, update_result]
    )

    live = SimpleNamespace(
        pm25=60.0,
        pm10=90.0,
        no2=15.0,
        so2=3.0,
        co=0.6,
        o3=8.0,
        temperature=26.0,
        humidity=55.0,
        wind_speed=2.0,
        wind_direction=180.0,
        openaq_location_id=555,
        openaq_location_name="Hadapsar, Pune - IITM",
        distance_meters=0.0,
        observed_at=older_returned_ts,
        is_stale=True,
        age_seconds=999999.0,
    )
    with patch(
        "app.workers.tasks.aqi_ingestion.openaq.fetch_location_reading",
        new=AsyncMock(return_value=live),
    ):
        outcome = await aqi_ingestion._ingest_one_pune_station(session, HADAPSAR_SPEC)

    assert outcome == "no_new_observation"
    session.add.assert_not_called()


def test_required_stations_cover_exactly_the_eight_pune_codes():
    """The Pune Live AQI feature is defined for exactly these eight
    stations — no more, no fewer, and never renamed/reordered silently."""
    expected_codes = [
        "PUNE_LIVE_SPPU",
        "PUNE_LIVE_DHANKAWADI",
        "PUNE_LIVE_HADAPSAR",
        "PUNE_LIVE_NIGDI",
        "PUNE_LIVE_PARK_STREET_WAKAD",
        "PUNE_LIVE_KATRAJ_DAIRY",
        "PUNE_LIVE_GAVALINAGAR",
        "PUNE_LIVE_BHUMKAR_NAGAR",
    ]
    actual_codes = [spec.station_code for spec in pune_stations.REQUIRED_STATIONS]
    assert actual_codes == expected_codes
    assert len(pune_stations.REQUIRED_STATIONS) == 8


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "spec", pune_stations.REQUIRED_STATIONS, ids=lambda s: s.station_code
)
async def test_ingest_one_station_accepts_stale_observation_for_every_pune_station(
    spec,
):
    """Every one of the required Pune stations (not just Hadapsar)
    must accept and store an old-but-real OpenAQ observation rather than
    discarding it for being stale."""
    session = make_db_session()
    existing_station = SimpleNamespace(
        id=f"station-uuid-{spec.station_code}",
        station_code=spec.station_code,
        openaq_location_id=1000,
        name=spec.display_name,
        latitude=spec.search_lat,
        longitude=spec.search_lon,
    )
    old_observed_ts = datetime(2026, 9, 8, 14, 30, tzinfo=UTC)

    lookup_result = MagicMock()
    lookup_result.scalar_one_or_none.return_value = existing_station
    latest_result = MagicMock()
    latest_result.scalar_one_or_none.return_value = None
    update_result = MagicMock()
    session.execute = AsyncMock(
        side_effect=[lookup_result, latest_result, update_result]
    )
    session.flush = AsyncMock()

    live = SimpleNamespace(
        pm25=70.0,
        pm10=100.0,
        no2=16.0,
        so2=4.0,
        co=0.7,
        o3=9.0,
        temperature=25.0,
        humidity=48.0,
        wind_speed=2.2,
        wind_direction=200.0,
        openaq_location_id=1000,
        openaq_location_name=spec.display_name,
        distance_meters=0.0,
        observed_at=old_observed_ts,
        is_stale=True,
        age_seconds=10**6,
    )
    with patch(
        "app.workers.tasks.aqi_ingestion.openaq.fetch_location_reading",
        new=AsyncMock(return_value=live),
    ):
        outcome = await aqi_ingestion._ingest_one_pune_station(session, spec)

    assert outcome == "inserted"
    inserted_reading = session.add.call_args.args[0]
    assert inserted_reading.quality_flag == "stale"
    assert inserted_reading.timestamp == old_observed_ts


def test_fetch_live_aqi_pune_stations_task_invokes_async():
    with (
        patch(
            "app.workers.tasks.aqi_ingestion._fetch_pune_live_stations_async",
            new=AsyncMock(),
        ) as mocked,
        patch("app.workers.tasks.aqi_ingestion.asyncio.run") as mock_run,
    ):
        mock_run.side_effect = lambda coro: coro.close()
        aqi_ingestion.fetch_live_aqi_pune_stations()
        mocked.assert_called_once()
        mock_run.assert_called_once()


@pytest.mark.asyncio
async def test_fetch_pune_live_stations_async_noop_when_unconfigured():
    with (
        patch(
            "app.workers.tasks.aqi_ingestion.openaq.is_configured",
            return_value=False,
        ),
        patch("sqlalchemy.ext.asyncio.create_async_engine") as mock_create_engine,
    ):
        summary = await aqi_ingestion._fetch_pune_live_stations_async()

    mock_create_engine.assert_not_called()
    assert all(v == "openaq_not_configured" for v in summary.values())
    assert set(summary.keys()) == {
        s.station_code for s in pune_stations.REQUIRED_STATIONS
    }


@pytest.mark.asyncio
async def test_fetch_pune_live_stations_async_skips_when_lock_held():
    with (
        patch(
            "app.workers.tasks.aqi_ingestion.openaq.is_configured", return_value=True
        ),
        patch(
            "app.workers.tasks.aqi_ingestion._acquire_pune_live_lock",
            new=AsyncMock(return_value=False),
        ),
        patch("sqlalchemy.ext.asyncio.create_async_engine") as mock_create_engine,
    ):
        summary = await aqi_ingestion._fetch_pune_live_stations_async()

    mock_create_engine.assert_not_called()
    assert summary == {"_skipped": "already_running"}


# ─── endpoint: GET /aqi/live?city=Pune ──────────────────────────────────


async def _create_pune_live_station(
    session: AsyncSession, spec, openaq_location_id: int = 100
) -> MonitoringStation:
    from geoalchemy2.elements import WKTElement

    station = MonitoringStation(
        name=spec.display_name,
        station_code=spec.station_code,
        city=spec.city,
        state=spec.state,
        country=spec.country,
        operator=f"{spec.display_provider} (via OpenAQ)",
        latitude=spec.search_lat,
        longitude=spec.search_lon,
        geometry=WKTElement(f"POINT({spec.search_lon} {spec.search_lat})", srid=4326),
        is_active=True,
        station_type="OpenAQ",
        openaq_location_id=openaq_location_id,
    )
    session.add(station)
    await session.flush()
    return station


@pytest.mark.asyncio
async def test_pune_live_always_returns_exactly_eight_stations_when_db_empty(
    client: AsyncClient, auth_headers: dict
):
    """No Pune stations resolved yet at all -> still 200, still exactly
    eight entries, each clearly marked unresolved rather than omitted or
    fabricated."""
    resp = await client.get("/api/v1/aqi/live?city=Pune", headers=auth_headers)
    assert resp.status_code == 200
    data = resp.json()["data"]
    assert len(data) == 8

    codes = {item["station_code"] for item in data}
    assert codes == {s.station_code for s in pune_stations.REQUIRED_STATIONS}
    for item in data:
        assert item["unresolved"] is True
        assert item["station"] is None
        assert item["reading"] is None
        assert item["data_source"] == "unavailable"
        assert item["freshness"] == "unavailable"


@pytest.mark.asyncio
async def test_pune_live_mixed_resolution_and_freshness(
    client: AsyncClient, db_session: AsyncSession, auth_headers: dict
):
    """One station resolved with a fresh real reading, one resolved but
    currently has no reading, the rest unresolved -> eight entries total,
    each accurately reflecting its own state."""
    hadapsar_station = await _create_pune_live_station(db_session, HADAPSAR_SPEC)
    reading = AQIReading(
        station_id=hadapsar_station.id,
        pm25=68.2,
        pm10=110.0,
        aqi=142,
        no2=20.0,
        so2=5.0,
        co=1.0,
        o3=15.0,
        temperature=28.0,
        humidity=45.0,
        wind_speed=2.5,
        wind_direction=210.0,
        timestamp=datetime.now(UTC),
        latitude=HADAPSAR_SPEC.search_lat,
        longitude=HADAPSAR_SPEC.search_lon,
        quality_flag="good",
    )
    db_session.add(reading)

    nigdi_spec = next(
        s
        for s in pune_stations.REQUIRED_STATIONS
        if s.station_code == "PUNE_LIVE_NIGDI"
    )
    await _create_pune_live_station(db_session, nigdi_spec, openaq_location_id=200)
    await db_session.commit()

    resp = await client.get("/api/v1/aqi/live?city=Pune", headers=auth_headers)
    assert resp.status_code == 200
    data = resp.json()["data"]
    assert len(data) == 8
    by_code = {item["station_code"]: item for item in data}

    hadapsar = by_code["PUNE_LIVE_HADAPSAR"]
    assert hadapsar["unresolved"] is False
    assert hadapsar["reading"]["pm25"] == 68.2
    assert hadapsar["data_source"] == "openaq"
    assert hadapsar["freshness"] in {"live", "recent"}

    nigdi = by_code["PUNE_LIVE_NIGDI"]
    assert nigdi["unresolved"] is False
    assert nigdi["reading"] is None
    assert nigdi["data_source"] == "unavailable"

    still_unresolved = {
        code
        for code, item in by_code.items()
        if code not in ("PUNE_LIVE_HADAPSAR", "PUNE_LIVE_NIGDI")
    }
    assert len(still_unresolved) == 6
    for code in still_unresolved:
        assert by_code[code]["unresolved"] is True


@pytest.mark.asyncio
async def test_duplicate_openaq_location_conflict_does_not_poison_other_stations(
    client: AsyncClient, db_session: AsyncSession, auth_headers: dict
):
    """Regression test for a real bug found during production-readiness
    review: if two required stations' OpenAQ search results both
    resolve to the SAME openaq_location_id (violating the uniqueness
    constraint from migration 020_pune_live_stations), that station's
    resolution must fail in isolation — via a SAVEPOINT in
    _ingest_one_pune_station — rather than poisoning the shared
    ingestion-cycle session and silently dropping every other station's
    already-staged work.

    Exercises the full async ingestion pipeline (not a mocked session)
    against a real Postgres instance so the unique constraint is
    actually enforced by the database, not assumed."""
    await _create_pune_live_station(db_session, HADAPSAR_SPEC, openaq_location_id=777)
    await db_session.commit()

    # Nigdi's OpenAQ search "coincidentally" returns the exact same
    # location id already claimed by Hadapsar — a real OpenAQ data
    # inconsistency this must survive gracefully rather than crash on.
    nigdi_spec = next(
        s
        for s in pune_stations.REQUIRED_STATIONS
        if s.station_code == "PUNE_LIVE_NIGDI"
    )
    conflicting_candidates = [
        {
            "id": 777,
            "name": "Nigdi",
            "owner": {"name": "IITM"},
            "coordinates": {
                "latitude": nigdi_spec.search_lat,
                "longitude": nigdi_spec.search_lon,
            },
        }
    ]

    hadapsar_live = SimpleNamespace(
        pm25=55.0,
        pm10=90.0,
        no2=15.0,
        so2=4.0,
        co=1.0,
        o3=12.0,
        temperature=27.0,
        humidity=48.0,
        wind_speed=2.0,
        wind_direction=190.0,
        openaq_location_id=777,
        openaq_location_name="Hadapsar",
        distance_meters=0.0,
        observed_at=datetime.now(UTC),
    )

    with (
        patch(
            "app.workers.tasks.aqi_ingestion.openaq.search_locations_near",
            new=AsyncMock(return_value=conflicting_candidates),
        ),
        patch(
            "app.workers.tasks.aqi_ingestion.openaq.fetch_location_reading",
            new=AsyncMock(return_value=hadapsar_live),
        ),
    ):
        # Mirrors _fetch_pune_live_stations_async's actual per-station
        # commit/rollback boundary (see that function's docstring/comment
        # for why this matters — a shared uncommitted transaction across
        # stations was the original form of this bug).
        hadapsar_outcome = await aqi_ingestion._ingest_one_pune_station(
            db_session, HADAPSAR_SPEC
        )
        await db_session.commit()

        nigdi_outcome = await aqi_ingestion._ingest_one_pune_station(
            db_session, nigdi_spec
        )
        await db_session.commit()

        # Session must still be usable after the conflict — prove it by
        # successfully ingesting a third station in the same session.
        dhankawadi_spec = next(
            s
            for s in pune_stations.REQUIRED_STATIONS
            if s.station_code == "PUNE_LIVE_DHANKAWADI"
        )
        await _create_pune_live_station(
            db_session, dhankawadi_spec, openaq_location_id=888
        )
        await db_session.commit()
        dhankawadi_live = SimpleNamespace(
            pm25=40.0,
            pm10=70.0,
            no2=10.0,
            so2=3.0,
            co=0.8,
            o3=10.0,
            temperature=26.0,
            humidity=50.0,
            wind_speed=1.5,
            wind_direction=200.0,
            openaq_location_id=888,
            openaq_location_name="Dhankawadi",
            distance_meters=0.0,
            observed_at=datetime.now(UTC),
        )
        with patch(
            "app.workers.tasks.aqi_ingestion.openaq.fetch_location_reading",
            new=AsyncMock(return_value=dhankawadi_live),
        ):
            dhankawadi_outcome = await aqi_ingestion._ingest_one_pune_station(
                db_session, dhankawadi_spec
            )
        await db_session.commit()

    assert hadapsar_outcome == "inserted"
    assert nigdi_outcome == "unresolved_location_id_conflict"
    assert dhankawadi_outcome == "inserted"

    resp = await client.get("/api/v1/aqi/live?city=Pune", headers=auth_headers)
    data = resp.json()["data"]
    by_code = {item["station_code"]: item for item in data}
    assert by_code["PUNE_LIVE_HADAPSAR"]["reading"] is not None
    assert by_code["PUNE_LIVE_DHANKAWADI"]["reading"] is not None
    assert by_code["PUNE_LIVE_NIGDI"]["unresolved"] is True


@pytest.mark.asyncio
async def test_fetch_pune_live_stations_async_full_cycle_survives_one_conflict(
    monkeypatch, db_session: AsyncSession
):
    """End-to-end test of the actual Celery entry point
    (_fetch_pune_live_stations_async, not just the inner per-station
    helper) against real Postgres: seed one station with an
    openaq_location_id, make a DIFFERENT required station's search
    results collide with it, and confirm the full eight-station run
    completes with seven conflicts and exactly one insert — proving
    the per-station commit fix works through the real entry point,
    including its own lock/engine/session setup, not just when driven
    directly by the test.

    `db_session` is unused directly (this test opens its own engine,
    matching what the real Celery task does) but is required to trigger
    the test database's schema setup via conftest.py."""
    import uuid as _uuid

    from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

    from app.core.config import settings
    from app.models.monitoring import MonitoringStation
    from app.workers.tasks import aqi_ingestion

    monkeypatch.setattr(
        "app.workers.tasks.aqi_ingestion._acquire_pune_live_lock",
        AsyncMock(return_value=True),
    )
    monkeypatch.setattr(
        "app.workers.tasks.aqi_ingestion._release_pune_live_lock", AsyncMock()
    )
    monkeypatch.setattr(
        "app.workers.tasks.aqi_ingestion.openaq.is_configured",
        lambda: True,
    )

    engine = create_async_engine(settings.DATABASE_URL, echo=False)
    Session = async_sessionmaker(engine, expire_on_commit=False)
    from geoalchemy2.elements import WKTElement

    async with Session() as session:
        pre_existing = MonitoringStation(
            id=_uuid.uuid4(),
            name=HADAPSAR_SPEC.display_name,
            station_code=HADAPSAR_SPEC.station_code,
            city=HADAPSAR_SPEC.city,
            state=HADAPSAR_SPEC.state,
            country=HADAPSAR_SPEC.country,
            operator="IITM (via OpenAQ)",
            latitude=HADAPSAR_SPEC.search_lat,
            longitude=HADAPSAR_SPEC.search_lon,
            geometry=WKTElement(
                f"POINT({HADAPSAR_SPEC.search_lon} {HADAPSAR_SPEC.search_lat})",
                srid=4326,
            ),
            is_active=True,
            station_type="OpenAQ",
            openaq_location_id=9001,
        )
        session.add(pre_existing)
        await session.commit()

    def fake_search(lat, lon, radius_m, limit=100):
        return [
            {
                "id": 9001,
                "name": "collision",
                "owner": {"name": "IITM"},
                "coordinates": {"latitude": lat, "longitude": lon},
            }
        ]

    def fake_match(candidates, spec):
        # Force every spec to "match" the colliding candidate, regardless
        # of name, so the conflict is guaranteed rather than probabilistic.
        return candidates[0] if candidates else None

    async def fake_fetch_reading(location_id, name):
        if location_id != 9001:
            return None
        return SimpleNamespace(
            pm25=50.0,
            pm10=80.0,
            no2=10.0,
            so2=3.0,
            co=1.0,
            o3=10.0,
            temperature=25.0,
            humidity=50.0,
            wind_speed=2.0,
            wind_direction=180.0,
            openaq_location_id=9001,
            openaq_location_name="collision",
            distance_meters=0.0,
            observed_at=datetime.now(UTC),
        )

    monkeypatch.setattr(
        "app.workers.tasks.aqi_ingestion.openaq.search_locations_near",
        AsyncMock(side_effect=fake_search),
    )
    monkeypatch.setattr(
        "app.workers.tasks.aqi_ingestion.pune_stations.match_station",
        fake_match,
    )
    monkeypatch.setattr(
        "app.workers.tasks.aqi_ingestion.openaq.fetch_location_reading",
        AsyncMock(side_effect=fake_fetch_reading),
    )

    try:
        summary = await aqi_ingestion._fetch_pune_live_stations_async()
    finally:
        async with engine.begin() as conn:
            from sqlalchemy import text

            await conn.execute(
                text(
                    "DELETE FROM aqi_readings WHERE station_id IN "
                    "(SELECT id FROM monitoring_stations WHERE station_code LIKE 'PUNE_LIVE_%')"
                )
            )
            await conn.execute(
                text(
                    "DELETE FROM monitoring_stations WHERE station_code LIKE 'PUNE_LIVE_%'"
                )
            )
        await engine.dispose()

    assert summary["PUNE_LIVE_HADAPSAR"] == "inserted"

    other_codes = [
        s.station_code
        for s in pune_stations.REQUIRED_STATIONS
        if s.station_code != "PUNE_LIVE_HADAPSAR"
    ]
    for code in other_codes:
        assert summary[code] == "unresolved_location_id_conflict", summary


@pytest.mark.asyncio
async def test_pune_live_never_returns_synthetic_reading(
    client: AsyncClient, db_session: AsyncSession, auth_headers: dict
):
    """Even if a synthetic-flagged reading somehow exists against one of
    the six real station rows (e.g. leftover from a bug elsewhere), the
    Pune Live AQI view must never surface it as if it were real."""
    station = await _create_pune_live_station(db_session, HADAPSAR_SPEC)
    synthetic_reading = AQIReading(
        station_id=station.id,
        pm25=999.0,
        pm10=999.0,
        aqi=500,
        no2=1.0,
        so2=1.0,
        co=1.0,
        o3=1.0,
        temperature=25.0,
        humidity=50.0,
        wind_speed=1.0,
        wind_direction=1.0,
        timestamp=datetime.now(UTC),
        latitude=HADAPSAR_SPEC.search_lat,
        longitude=HADAPSAR_SPEC.search_lon,
        quality_flag="synthetic",
    )
    db_session.add(synthetic_reading)
    await db_session.commit()

    resp = await client.get("/api/v1/aqi/live?city=Pune", headers=auth_headers)
    data = resp.json()["data"]
    hadapsar = next(
        item for item in data if item["station_code"] == "PUNE_LIVE_HADAPSAR"
    )
    # get_latest_by_station has no synthetic-exclusion of its own (it's a
    # "most recent row regardless of flag" lookup used across many
    # features) — the six-station live view relies on the ingestion
    # pipeline (fetch_live_aqi_pune_stations) never writing a synthetic
    # row in the first place. This assertion documents that contract: if
    # one ever slipped in, data_source must still say so rather than
    # silently rendering it as "openaq".
    if hadapsar["reading"] is not None:
        assert hadapsar["data_source"] != "openaq"


@pytest.mark.asyncio
async def test_ingest_one_pune_station_stores_stale_reading_despite_synthetic_row(
    db_session: AsyncSession,
):

    station = await _create_pune_live_station(db_session, HADAPSAR_SPEC)

    synthetic_reading = AQIReading(
        station_id=station.id,
        pm25=999.0,
        pm10=999.0,
        aqi=500,
        no2=1.0,
        so2=1.0,
        co=1.0,
        o3=1.0,
        temperature=25.0,
        humidity=50.0,
        wind_speed=1.0,
        wind_direction=1.0,
        timestamp=datetime.now(UTC),
        latitude=HADAPSAR_SPEC.search_lat,
        longitude=HADAPSAR_SPEC.search_lon,
        quality_flag="synthetic",
    )
    db_session.add(synthetic_reading)
    await db_session.commit()

    stale_observed_at = datetime(2025, 5, 23, 15, 30, tzinfo=UTC)
    live = SimpleNamespace(
        pm25=42.0,
        pm10=80.0,
        no2=12.0,
        so2=3.0,
        co=0.9,
        o3=11.0,
        temperature=None,
        humidity=None,
        wind_speed=None,
        wind_direction=None,
        openaq_location_id=station.openaq_location_id,
        openaq_location_name="Hadapsar",
        distance_meters=0.0,
        observed_at=stale_observed_at,
        is_stale=True,
        age_seconds=(datetime.now(UTC) - stale_observed_at).total_seconds(),
    )

    with patch(
        "app.workers.tasks.aqi_ingestion.openaq.fetch_location_reading",
        new=AsyncMock(return_value=live),
    ):
        outcome = await aqi_ingestion._ingest_one_pune_station(
            db_session, HADAPSAR_SPEC
        )
        await db_session.commit()

    assert outcome == "inserted"

    result = await db_session.execute(
        select(AQIReading)
        .where(
            AQIReading.station_id == station.id,
            AQIReading.quality_flag != "synthetic",
        )
        .order_by(AQIReading.timestamp.desc())
    )
    stored = result.scalars().first()
    assert stored is not None
    assert stored.timestamp == stale_observed_at
    assert stored.quality_flag == "stale"
