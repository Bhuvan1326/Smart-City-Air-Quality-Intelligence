from fastapi import APIRouter

from app.api.v1.endpoints.agents import router as agents_router
from app.api.v1.endpoints.alerts import (
    alerts_router,
    attribution_router,
    mitigation_router,
    thresholds_router,
)
from app.api.v1.endpoints.analytics import router as analytics_router
from app.api.v1.endpoints.aqi import router as aqi_router
from app.api.v1.endpoints.assistant import router as assistant_router
from app.api.v1.endpoints.auth import router as auth_router
from app.api.v1.endpoints.civic import router as civic_router
from app.api.v1.endpoints.construction_dust import router as construction_dust_router
from app.api.v1.endpoints.dashboard import router as dashboard_router
from app.api.v1.endpoints.data_sources import router as data_sources_router
from app.api.v1.endpoints.drone import router as drone_router
from app.api.v1.endpoints.energy import router as energy_router
from app.api.v1.endpoints.enforcement import router as enforcement_router
from app.api.v1.endpoints.exposure import demographics_router, exposure_router
from app.api.v1.endpoints.forecast import router as forecast_router
from app.api.v1.endpoints.gis import router as gis_router
from app.api.v1.endpoints.green_infrastructure import (
    router as green_infrastructure_router,
)
from app.api.v1.endpoints.heat import router as heat_router
from app.api.v1.endpoints.industrial_pollution import (
    router as industrial_pollution_router,
)
from app.api.v1.endpoints.metrics import router as metrics_router
from app.api.v1.endpoints.model_performance import router as model_performance_router
from app.api.v1.endpoints.notifications import router as notifications_router
from app.api.v1.endpoints.replay import router as replay_router
from app.api.v1.endpoints.reports import router as reports_router
from app.api.v1.endpoints.sensors import router as sensors_router
from app.api.v1.endpoints.simulator import router as simulator_router
from app.api.v1.endpoints.sustainability import router as sustainability_router
from app.api.v1.endpoints.traffic import router as traffic_router
from app.api.v1.endpoints.waste_burning import router as waste_burning_router
from app.api.v1.endpoints.waste_circularity import router as waste_circularity_router
from app.api.v1.endpoints.water import router as water_router

api_router = APIRouter(prefix="/api/v1")

api_router.include_router(auth_router)
api_router.include_router(dashboard_router)
api_router.include_router(aqi_router)
api_router.include_router(forecast_router)
api_router.include_router(attribution_router)
api_router.include_router(enforcement_router)
api_router.include_router(alerts_router)
api_router.include_router(thresholds_router)
api_router.include_router(mitigation_router)
api_router.include_router(analytics_router)
api_router.include_router(assistant_router)
api_router.include_router(construction_dust_router)
api_router.include_router(agents_router)
api_router.include_router(gis_router)
api_router.include_router(simulator_router)
api_router.include_router(replay_router)
api_router.include_router(reports_router)
api_router.include_router(metrics_router)
api_router.include_router(sensors_router)
api_router.include_router(notifications_router)
api_router.include_router(drone_router)
api_router.include_router(exposure_router)
api_router.include_router(demographics_router)
api_router.include_router(green_infrastructure_router)
api_router.include_router(waste_burning_router)
api_router.include_router(industrial_pollution_router)
api_router.include_router(data_sources_router)
api_router.include_router(civic_router)
api_router.include_router(energy_router)
api_router.include_router(heat_router)
api_router.include_router(waste_circularity_router)
api_router.include_router(water_router)
api_router.include_router(model_performance_router)
api_router.include_router(traffic_router)
api_router.include_router(sustainability_router)
