export { default } from "./page";
