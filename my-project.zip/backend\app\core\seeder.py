"""
Demo data seeder — runs on startup in development mode. Seeds every city
that has monitoring stations defined (currently Pune and Mumbai), not
just Pune. Uses only free/open data sources. No paid API keys required
for demo.
"""

import hashlib
import random
from datetime import UTC, date, datetime, timedelta

from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from app.core.config import settings
from app.core.logging import logger
from app.core.security import hash_password
from app.workers.tasks.aqi_ingestion import calculate_overall_aqi


async def seed_all():
    engine = create_async_engine(settings.DATABASE_URL, echo=False)
    AsyncSession = async_sessionmaker(engine, expire_on_commit=False)

    async with AsyncSession() as session:
        already = await session.scalar(
            text("SELECT COUNT(*) FROM users WHERE is_deleted = false")
        )
        if already and already > 0:
            logger.info("seed.skipped", reason="data already exists")
            await engine.dispose()
            return

        logger.info("seed.starting")
        await _seed_users(session)
        await _seed_stations(session)
        await _seed_emission_sources(session)
        station_ids = await _seed_aqi_readings(session)
        await _seed_forecasts(session)
        await _seed_attributions(session)
        await _seed_anomalies(session, station_ids)
        await _seed_enforcement(session)
        await _seed_outcomes(session)
        await _seed_policy_snapshots(session)
        await _seed_alerts(session)
        await _seed_alert_thresholds(session)
        await _seed_ward_demographics(session)
        await session.commit()

        # BUG 006 (continued): the live/aggregate endpoints (attribution,
        # dashboard, analytics, etc.) cache their responses in Redis. If
        # any of them were hit even once before this seed ran, a stale
        # (often empty) cached result would otherwise be served for up to
        # its TTL, masking freshly-seeded data. Clear the caches this
        # seed run could have made stale so the app reflects the new data
        # immediately instead of appearing broken for a few minutes.
        try:
            from app.core.redis_client import cache_delete_pattern

            for pattern in (
                "attribution:*",
                "dashboard:*",
                "analytics:*",
                "aqi:*",
                "forecast:*",
            ):
                await cache_delete_pattern(pattern)
        except Exception as exc:  # pragma: no cover - best-effort cleanup
            logger.warning("seed.cache_clear_failed", error=str(exc))

        logger.info("seed.complete")

    await engine.dispose()


async def _seed_users(session):
    from app.models.user import User, UserRole

    users = [
        User(
            email="admin@pune.gov.in",
            hashed_password=hash_password("Admin@123"),
            full_name="Priya Sharma",
            role=UserRole.CITY_ADMINISTRATOR,
            city="Pune",
            preferred_language="en",
            is_active=True,
        ),
        User(
            email="officer@mpcb.gov.in",
            hashed_password=hash_password("Officer@123"),
            full_name="Rajesh Patil",
            role=UserRole.POLLUTION_CONTROL_OFFICER,
            city="Pune",
            preferred_language="mr",
            is_active=True,
        ),
        User(
            email="inspector@pune.gov.in",
            hashed_password=hash_password("Inspector@123"),
            full_name="Amit Desai",
            role=UserRole.FIELD_INSPECTOR,
            city="Pune",
            ward_id="W07",
            preferred_language="en",
            is_active=True,
        ),
        User(
            email="citizen@pune.in",
            hashed_password=hash_password("Citizen@123"),
            full_name="Sunita Kulkarni",
            role=UserRole.CITIZEN,
            city="Pune",
            ward_id="W02",
            preferred_language="mr",
            is_active=True,
        ),
    ]
    session.add_all(users)
    await session.flush()
    logger.info("seed.users", count=len(users))


async def _seed_stations(session):
    from geoalchemy2.elements import WKTElement

    from app.models.monitoring import MonitoringStation

    stations_data = [
        ("PUNE_001", "Karve Road CAAQMS", "W01", 18.5074, 73.8077),
        ("PUNE_002", "Shivajinagar CAAQMS", "W02", 18.5308, 73.8475),
        ("PUNE_003", "Hadapsar CAAQMS", "W03", 18.5089, 73.9259),
        ("PUNE_004", "Pimpri CAAQMS", "W04", 18.6298, 73.7997),
        ("PUNE_005", "Katraj CAAQMS", "W05", 18.4530, 73.8618),
        ("PUNE_006", "Wakad CAAQMS", "W06", 18.5989, 73.7601),
        ("PUNE_007", "Kothrud CAAQMS", "W07", 18.4968, 73.8126),
        ("PUNE_008", "Yerawada CAAQMS", "W08", 18.5559, 73.9007),
        # Pune Authoritative Live Stations
        ("PUNE_LIVE_SPPU", "Savitribai Phule Pune University", "W02", 18.5529, 73.8228),
        ("PUNE_LIVE_ALANDI", "Alandi", "W04", 18.6780, 73.9040),
        ("PUNE_LIVE_DHANKAWADI", "Dhankawadi", "W05", 18.4600, 73.8480),
        ("PUNE_LIVE_HADAPSAR", "Hadapsar", "W03", 18.5089, 73.9259),
        ("PUNE_LIVE_KARVE_ROAD", "Karve Road", "W01", 18.5019, 73.8225),
        ("PUNE_LIVE_NIGDI", "Nigdi", "W06", 18.6520, 73.7780),
        # Mumbai
        ("MUM_001", "Andheri CAAQMS", "K/W", 19.1136, 72.8697),
        ("MUM_002", "Bandra CAAQMS", "H/W", 19.0596, 72.8295),
        ("MUM_003", "Worli CAAQMS", "G/S", 19.0177, 72.8139),
    ]

    # Idempotency guard: `docker compose down` (without `-v`) leaves the
    # `pgdata` named volume — and everything in it, including these ward
    # fixture rows — intact across restarts. The top-level `seed_all()`
    # gate only checks the `users` table, so any prior run/test that left
    # `monitoring_stations` populated without also leaving `users`
    # populated (e.g. a users-only cleanup between runs) previously made
    # this INSERT collide on `ix_stations_code` (observed as
    # `duplicate key value violates unique constraint "ix_stations_code"`,
    # `Key (station_code)=(PUNE_001) already exists`), which aborted the
    # whole seed transaction — silently rolling back the just-inserted
    # admin/officer/inspector/citizen users too and breaking login.
    # Skipping codes that already exist keeps seeding safe to re-run
    # without deleting/overwriting any legitimate existing row and without
    # touching the uniqueness constraint itself.
    existing_result = await session.execute(
        select(MonitoringStation.station_code).where(
            MonitoringStation.station_code.in_([code for code, *_ in stations_data])
        )
    )
    existing_codes = set(existing_result.scalars().all())

    stations = []
    for code, name, ward, lat, lon in stations_data:
        if code in existing_codes:
            continue
        city = "Pune" if code.startswith("PUNE") else "Mumbai"
        geom = WKTElement(f"POINT({lon} {lat})", srid=4326)
        stations.append(
            MonitoringStation(
                name=name,
                station_code=code,
                city=city,
                ward_id=ward,
                operator="MPCB / CPCB",
                latitude=lat,
                longitude=lon,
                geometry=geom,
                is_active=True,
                station_type="CAAQMS",
                installed_at=datetime(2021, 4, 1, tzinfo=UTC),
                maintenance_score=random.uniform(0.75, 0.98),
            )
        )

    session.add_all(stations)
    await session.flush()
    logger.info(
        "seed.stations", count=len(stations), skipped_existing=len(existing_codes)
    )


async def _seed_emission_sources(session):
    from geoalchemy2.elements import WKTElement

    from app.models.emission_source import (
        EmissionSource,
        EmissionSourceType,
        PermitStatus,
    )

    sources_data = [
        (
            "Pimpri Chinchwad Industrial Cluster",
            EmissionSourceType.INDUSTRIAL,
            "W04",
            18.6298,
            73.7997,
            PermitStatus.VALID,
            0,
        ),
        (
            "Hadapsar Industrial Estate",
            EmissionSourceType.INDUSTRIAL,
            "W03",
            18.5089,
            73.9259,
            PermitStatus.EXPIRED,
            3,
        ),
        (
            "Shivajinagar Construction Site A",
            EmissionSourceType.CONSTRUCTION,
            "W02",
            18.5350,
            73.8510,
            PermitStatus.VALID,
            1,
        ),
        (
            "Karve Road Traffic Corridor",
            EmissionSourceType.VEHICULAR,
            "W01",
            18.5074,
            73.8077,
            PermitStatus.NONE,
            0,
        ),
        (
            "Katraj Waste Burning Site",
            EmissionSourceType.BIOMASS,
            "W05",
            18.4530,
            73.8618,
            PermitStatus.NONE,
            5,
        ),
        (
            "Wakad Metro Construction",
            EmissionSourceType.CONSTRUCTION,
            "W06",
            18.5989,
            73.7601,
            PermitStatus.VALID,
            0,
        ),
        (
            "Yerawada Brick Kiln",
            EmissionSourceType.INDUSTRIAL,
            "W08",
            18.5600,
            73.9050,
            PermitStatus.SUSPENDED,
            7,
        ),
        (
            "Kothrud Residential Burning",
            EmissionSourceType.BIOMASS,
            "W07",
            18.4968,
            73.8126,
            PermitStatus.NONE,
            2,
        ),
    ]

    sources = []
    for name, stype, ward, lat, lon, permit, violations in sources_data:
        geom = WKTElement(f"POINT({lon} {lat})", srid=4326)
        sources.append(
            EmissionSource(
                name=name,
                source_type=stype,
                city="Pune",
                ward_id=ward,
                latitude=lat,
                longitude=lon,
                geometry=geom,
                permit_status=permit,
                violation_count=violations,
                operator_name=f"{name} Operator",
                is_active=True,
                last_inspected_at=datetime.now(UTC)
                - timedelta(days=random.randint(10, 90)),
                emission_rate_kg_hr=random.uniform(5, 120),
                carbon_estimate_ton_yr=random.uniform(50, 800),
            )
        )

    session.add_all(sources)
    await session.flush()
    logger.info("seed.emission_sources", count=len(sources))


async def _seed_aqi_readings(session) -> list:
    from app.models.monitoring import AQIReading

    result = await session.execute(
        select(text("id, city, latitude, longitude, ward_id, station_code"))
        .select_from(text("monitoring_stations"))
        .where(text("is_deleted = false"))
    )
    stations = result.fetchall()

    # Curated baselines for Pune's fixture wards (kept as-is so existing
    # demo data/expectations don't shift). Any other city/ward — e.g.
    # Mumbai's — gets a deterministic, station-specific baseline instead
    # of silently defaulting to 70 for everyone (BUG 006: the seed data
    # must actually vary per real station, not just Pune's).
    WARD_BASELINES = {
        "W01": 68,
        "W02": 72,
        "W03": 95,
        "W04": 105,
        "W05": 62,
        "W06": 58,
        "W07": 78,
        "W08": 70,
    }

    def _baseline_for(station) -> float:
        if station.ward_id in WARD_BASELINES:
            return WARD_BASELINES[station.ward_id]
        # Deterministic (stable across re-seeds) pseudo-baseline in a
        # realistic AQI range, derived from the station's own code so
        # different stations in the same city still vary.
        digest = int(hashlib.sha256(station.station_code.encode()).hexdigest(), 16)
        return 55 + (digest % 55)  # 55–109

    readings = []
    now = datetime.now(UTC)
    # 7 days of hourly readings
    for hours_back in range(168, 0, -1):
        ts = now - timedelta(hours=hours_back)
        hour = ts.hour
        dow = ts.weekday()
        traffic = (
            1.5 if (7 <= hour <= 10 or 17 <= hour <= 20) else (0.6 if hour < 5 else 1.0)
        )
        if dow >= 5:
            traffic *= 0.8

        for s in stations:
            baseline = _baseline_for(s)
            pm25 = baseline * traffic * random.uniform(0.85, 1.15)
            pm10 = pm25 * random.uniform(1.6, 2.1)
            no2 = 25 + traffic * 18 * random.uniform(0.8, 1.2)
            so2 = round(random.uniform(5, 20), 2)
            co = round(0.8 + traffic * 0.5 * random.uniform(0.8, 1.2), 2)
            o3 = round(max(0, 35 - traffic * 8 + random.uniform(-8, 8)), 2)

            readings.append(
                AQIReading(
                    station_id=s.id,
                    pm25=round(pm25, 2),
                    pm10=round(pm10, 2),
                    no2=round(no2, 2),
                    so2=so2,
                    co=co,
                    o3=o3,
                    # BUG 017: overall AQI is the max sub-index across all
                    # measured pollutants, not PM2.5 alone.
                    aqi=calculate_overall_aqi(
                        pm25=pm25, pm10=pm10, no2=no2, so2=so2, co=co, o3=o3
                    ),
                    temperature=round(24 + random.uniform(-4, 8), 1),
                    humidity=round(55 + random.uniform(-20, 25), 1),
                    wind_speed=round(random.uniform(0.5, 7.0), 1),
                    wind_direction=round(random.uniform(0, 360), 1),
                    timestamp=ts,
                    latitude=s.latitude,
                    longitude=s.longitude,
                    quality_flag="synthetic",
                )
            )

    # Add current readings
    for s in stations:
        baseline = _baseline_for(s)
        hour = now.hour
        traffic = (
            1.5 if (7 <= hour <= 10 or 17 <= hour <= 20) else (0.6 if hour < 5 else 1.0)
        )
        pm25 = baseline * traffic * random.uniform(0.9, 1.1)
        pm10 = pm25 * 1.8
        no2 = 25 + traffic * 18
        so2 = round(random.uniform(5, 20), 2)
        co = round(0.8 + traffic * 0.5, 2)
        o3 = round(max(0, 35 - traffic * 8), 2)

        readings.append(
            AQIReading(
                station_id=s.id,
                pm25=round(pm25, 2),
                pm10=round(pm10, 2),
                no2=round(no2, 2),
                so2=so2,
                co=co,
                o3=o3,
                aqi=calculate_overall_aqi(
                    pm25=pm25, pm10=pm10, no2=no2, so2=so2, co=co, o3=o3
                ),
                temperature=round(26 + random.uniform(-2, 4), 1),
                humidity=round(58 + random.uniform(-10, 15), 1),
                wind_speed=round(random.uniform(1.0, 5.0), 1),
                wind_direction=round(random.uniform(0, 360), 1),
                timestamp=now,
                latitude=s.latitude,
                longitude=s.longitude,
                quality_flag="synthetic",
            )
        )

    # Bulk insert in chunks
    chunk_size = 200
    for i in range(0, len(readings), chunk_size):
        session.add_all(readings[i : i + chunk_size])
        await session.flush()

    logger.info(
        "seed.aqi_readings",
        count=len(readings),
        cities=len(
            {
                getattr(s, "city", None)
                for s in stations
                if getattr(s, "city", None) is not None
            }
        ),
    )
    return [s.id for s in stations]


async def _seed_forecasts(session):
    from geoalchemy2.elements import WKTElement

    from app.models.enforcement import ForecastGrid

    WARD_COORDS = {
        "W01": (18.5074, 73.8077),
        "W02": (18.5308, 73.8475),
        "W03": (18.5089, 73.9259),
        "W04": (18.6298, 73.7997),
        "W05": (18.4530, 73.8618),
        "W06": (18.5989, 73.7601),
        "W07": (18.4968, 73.8126),
        "W08": (18.5559, 73.9007),
    }
    BASELINES = {
        "W01": 68,
        "W02": 72,
        "W03": 95,
        "W04": 105,
        "W05": 62,
        "W06": 58,
        "W07": 78,
        "W08": 70,
    }
    now = datetime.now(UTC)
    grids = []

    for ward, (lat, lon) in WARD_COORDS.items():
        delta = 0.01
        geom = WKTElement(
            f"POLYGON(({lon-delta} {lat-delta},{lon+delta} {lat-delta},"
            f"{lon+delta} {lat+delta},{lon-delta} {lat+delta},{lon-delta} {lat-delta}))",
            srid=4326,
        )
        base = BASELINES.get(ward, 75)
        for h in range(1, 73):
            ft = now + timedelta(hours=h)
            hour = ft.hour
            traffic = (
                1.5
                if (7 <= hour <= 10 or 17 <= hour <= 20)
                else (0.6 if hour < 5 else 1.0)
            )
            if ft.weekday() >= 5:
                traffic *= 0.8
            aqi = max(10, int(base * traffic * random.uniform(0.9, 1.1)))
            confidence = max(0.55, 0.92 - h * 0.005)
            margin = int(aqi * (1 - confidence) * 1.5)
            grids.append(
                ForecastGrid(
                    city="Pune",
                    ward_id=ward,
                    grid_geometry=geom,
                    forecast_timestamp=ft,
                    generated_at=now,
                    aqi_forecast=aqi,
                    pm25_forecast=round(aqi * 0.55, 1),
                    pm10_forecast=round(aqi * 1.1, 1),
                    confidence_score=round(confidence, 3),
                    confidence_lower=max(0, aqi - margin),
                    confidence_upper=aqi + margin,
                    model_version="statistical-v1.0",
                    contributing_factors={
                        "traffic": 0.35,
                        "weather": 0.25,
                        "industrial": 0.20,
                        "seasonal": 0.20,
                    },
                    feature_importance={
                        "current_aqi": 0.38,
                        "hour_of_day": 0.22,
                        "ward_type": 0.18,
                        "day_of_week": 0.12,
                        "weather": 0.10,
                    },
                )
            )

    for i in range(0, len(grids), 200):
        session.add_all(grids[i : i + 200])
        await session.flush()
    logger.info("seed.forecasts", count=len(grids))


async def _seed_attributions(session):
    from geoalchemy2.elements import WKTElement

    from app.models.analytics import PollutionAttribution

    # BUG 006 fix (continued): attribution seeding previously only covered
    # Pune's 8 fixture wards via a static coordinate/baseline table, so
    # Mumbai (or any other seeded city) never got attribution data at all.
    # Derive the city/ward list and ward centroids from the stations that
    # were actually seeded, and the AQI baseline for each ward from the
    # AQI readings that were actually just seeded for it — so this stays
    # correct for whichever cities/wards really have data, automatically.
    ward_result = await session.execute(
        text(
            """
            SELECT s.city, s.ward_id,
                   AVG(s.latitude) AS lat, AVG(s.longitude) AS lon,
                   AVG(r.aqi) AS avg_aqi
            FROM monitoring_stations s
            JOIN aqi_readings r ON r.station_id = s.id
            WHERE s.is_deleted = false AND s.ward_id IS NOT NULL
              AND r.timestamp > NOW() - INTERVAL '2 hours'
            GROUP BY s.city, s.ward_id
            """
        )
    )
    ward_rows = [
        (row.city, row.ward_id, float(row.lat), float(row.lon), float(row.avg_aqi))
        for row in ward_result
        if row.avg_aqi is not None
    ]

    if not ward_rows:
        ward_coords = {
            "W01": (18.5074, 73.8077),
            "W02": (18.5308, 73.8475),
            "W03": (18.5089, 73.9259),
            "W04": (18.6298, 73.7997),
            "W05": (18.4530, 73.8618),
            "W06": (18.5989, 73.7601),
            "W07": (18.4968, 73.8126),
            "W08": (18.5559, 73.9007),
        }
        ward_baselines = {
            "W01": 68,
            "W02": 72,
            "W03": 95,
            "W04": 105,
            "W05": 62,
            "W06": 58,
            "W07": 78,
            "W08": 70,
        }
        ward_rows = [
            ("Pune", ward, lat, lon, ward_baselines[ward])
            for ward, (lat, lon) in ward_coords.items()
        ]

    now = datetime.now(UTC)
    records = []

    # BUG 006 fix: the previous range(48, 0, -6) stopped at hours_back=6,
    # so the freshest seeded attribution record was always ~6h old. The
    # live endpoint (`/attribution/live`) only returns records from the
    # last hour, so Pollution Sources appeared empty right after a fresh
    # seed. Including hours_back=0 seeds one snapshot at "now" so the live
    # endpoint has real (not fabricated) current data immediately after
    # seeding, for every city that actually has stations/readings.
    for hours_back in range(42, -1, -6):
        ts = now - timedelta(hours=hours_back)
        hour = ts.hour
        is_peak = 7 <= hour <= 10 or 17 <= hour <= 20
        dow = ts.weekday()
        is_weekend = dow >= 5

        for city, ward, lat, lon, ward_aqi in ward_rows:
            # Deterministic "is this an industrial-leaning ward" heuristic
            # so the mix still varies sensibly by ward without depending
            # on a Pune-only hard-coded ward-id list.
            is_ind = (
                int(hashlib.sha256(f"{city}:{ward}".encode()).hexdigest(), 16) % 4 == 0
            )

            industrial = (0.38 if is_ind else 0.12) * (0.8 if dow >= 5 else 1.0)
            vehicular = (0.40 if is_peak else 0.22) * (0.85 if dow >= 5 else 1.0)
            construction = 0.15 if dow < 5 else 0.08
            biomass = 0.08 if (5 <= hour <= 9) else 0.04
            dust = 0.10
            domestic = 0.06 if (6 <= hour <= 9 or 18 <= hour <= 21) else 0.03
            total = industrial + vehicular + construction + biomass + dust + domestic
            s = 1.0 / total

            # Mirrors app.workers.tasks.attribution._attribute_sources: a
            # continuous, multi-signal confidence estimate (AQI-level signal
            # strength, industrial-ward stability, peak-hour traffic
            # clarity, weekend unpredictability) rather than a value that
            # only ever takes one of two constants regardless of ward or
            # time.
            aqi_signal = min(1.0, max(0.0, (ward_aqi - 50) / 150))
            confidence = 0.58 + 0.22 * aqi_signal
            if is_ind:
                confidence += 0.05
            if is_peak and not is_ind:
                confidence += 0.03
            if is_weekend:
                confidence -= 0.04
            confidence = min(0.90, max(0.55, confidence))

            delta = 0.01
            geom = WKTElement(
                f"POLYGON(({lon-delta} {lat-delta},{lon+delta} {lat-delta},"
                f"{lon+delta} {lat+delta},{lon-delta} {lat+delta},{lon-delta} {lat-delta}))",
                srid=4326,
            )
            records.append(
                PollutionAttribution(
                    ward_id=ward,
                    city=city,
                    timestamp=ts,
                    vehicular_pct=round(vehicular * s * 100, 1),
                    industrial_pct=round(industrial * s * 100, 1),
                    construction_pct=round(construction * s * 100, 1),
                    biomass_pct=round(biomass * s * 100, 1),
                    secondary_aerosol_pct=0.0,
                    dust_pct=round(dust * s * 100, 1),
                    domestic_pct=round(domestic * s * 100, 1),
                    overall_confidence=round(confidence, 3),
                    contributing_sources={"thermal_hotspot": is_ind},
                    satellite_evidence={
                        "ndvi_anomaly": False,
                        "thermal_hotspot": is_ind,
                    },
                    model_version="receptor-model-v1.2",
                    geometry=geom,
                )
            )

    session.add_all(records)
    await session.flush()
    logger.info(
        "seed.attributions",
        count=len(records),
        cities=len({c for c, *_ in ward_rows}),
    )


async def _seed_anomalies(session, station_ids: list):
    from geoalchemy2.elements import WKTElement

    from app.models.analytics import AnomalyEvent
    from app.models.monitoring import MonitoringStation

    result = await session.execute(
        select(MonitoringStation).where(
            MonitoringStation.city == "Pune",
            MonitoringStation.is_deleted.is_(False),
        )
    )
    stations = result.scalars().all()
    now = datetime.now(UTC)

    events = [
        # The demo Ward 7 spike
        AnomalyEvent(
            station_id=next(s.id for s in stations if s.ward_id == "W07"),
            ward_id="W07",
            city="Pune",
            detected_at=now - timedelta(hours=1),
            aqi_spike_value=285,
            baseline_aqi=78,
            probable_cause="Construction activity spike combined with evening traffic peak",
            cause_category="construction",
            confidence_score=0.87,
            is_resolved=False,
            geometry=WKTElement("POINT(73.8126 18.4968)", srid=4326),
            root_cause_timeline={
                "baseline_aqi": 78,
                "spike_aqi": 285,
                "z_score": 4.8,
                "sequence": [
                    {
                        "time": (now - timedelta(hours=3)).isoformat(),
                        "event": "Construction site resumed operations after lunch break",
                        "aqi": 95,
                    },
                    {
                        "time": (now - timedelta(hours=2)).isoformat(),
                        "event": "Evening traffic peak began on Paud Road",
                        "aqi": 145,
                    },
                    {
                        "time": (now - timedelta(hours=1, minutes=30)).isoformat(),
                        "event": "Wind shifted to SE — concentrated dispersion toward station",
                        "aqi": 210,
                    },
                    {
                        "time": (now - timedelta(hours=1)).isoformat(),
                        "event": "AQI spike detected — threshold exceeded",
                        "aqi": 285,
                    },
                ],
            },
            contributing_sources={
                "construction": {"confidence": 0.87, "source": "Kothrud Metro Site"},
                "vehicular": {"confidence": 0.71, "source": "Paud Road corridor"},
            },
        ),
        AnomalyEvent(
            station_id=next(s.id for s in stations if s.ward_id == "W04"),
            ward_id="W04",
            city="Pune",
            detected_at=now - timedelta(hours=6),
            aqi_spike_value=310,
            baseline_aqi=105,
            probable_cause="Industrial stack emissions from Pimpri industrial cluster — shift change",
            cause_category="industrial",
            confidence_score=0.91,
            is_resolved=True,
            geometry=WKTElement("POINT(73.7997 18.6298)", srid=4326),
            root_cause_timeline={"baseline_aqi": 105, "spike_aqi": 310, "z_score": 5.2},
        ),
    ]
    session.add_all(events)
    await session.flush()
    logger.info("seed.anomalies", count=len(events))


async def _seed_enforcement(session):
    from geoalchemy2.elements import WKTElement

    from app.models.enforcement import ActionStatus, ActionType, EnforcementAction

    result = await session.execute(
        select(text("id"))
        .select_from(text("users"))
        .where(text("role = 'field_inspector'"))
    )
    inspector_id = result.scalar()
    result2 = await session.execute(
        select(text("id"))
        .select_from(text("users"))
        .where(text("role = 'pollution_control_officer'"))
    )
    officer_id = result2.scalar()

    result3 = await session.execute(
        select(text("id"))
        .select_from(text("emission_sources"))
        .where(text("city = 'Pune'"))
        .limit(4)
    )
    source_ids = [row[0] for row in result3.fetchall()]

    now = datetime.now(UTC)
    actions = [
        EnforcementAction(
            officer_id=inspector_id or officer_id,
            source_id=source_ids[0] if source_ids else None,
            ward_id="W07",
            city="Pune",
            action_type=ActionType.INSPECTION,
            status=ActionStatus.ASSIGNED,
            priority_score=92.5,
            title="Emergency inspection — Kothrud construction site AQI spike",
            description="AQI spike of 285 detected in W07. Construction dust identified as primary contributor (87% confidence). Immediate on-site inspection required.",
            latitude=18.4968,
            longitude=73.8126,
            geometry=WKTElement("POINT(73.8126 18.4968)", srid=4326),
            ai_reasoning={
                "trigger": "anomaly_detection",
                "aqi_spike": 285,
                "confidence": 0.87,
                "primary_source": "construction",
                "recommended_action": "Issue stop-work notice and dust suppression order",
                "supporting_evidence": ["sensor_W07_CAAQMS", "attribution_model_v1.2"],
            },
        ),
        EnforcementAction(
            officer_id=officer_id or inspector_id,
            source_id=source_ids[1] if len(source_ids) > 1 else None,
            ward_id="W08",
            city="Pune",
            action_type=ActionType.NOTICE,
            status=ActionStatus.COMPLETED,
            priority_score=78.0,
            title="Notice issued — Yerawada Brick Kiln permit violation",
            description="Operating with suspended permit. Stack emissions above NAAQS limits for SO2.",
            latitude=18.5600,
            longitude=73.9050,
            geometry=WKTElement("POINT(73.9050 18.5600)", srid=4326),
            outcome_score=65.0,
            resolved_at=now - timedelta(hours=18),
            ai_reasoning={
                "trigger": "permit_check",
                "violation_type": "expired_permit",
                "confidence": 0.95,
            },
        ),
        EnforcementAction(
            officer_id=inspector_id or officer_id,
            source_id=source_ids[2] if len(source_ids) > 2 else None,
            ward_id="W04",
            city="Pune",
            action_type=ActionType.SHUTDOWN,
            status=ActionStatus.PENDING,
            priority_score=88.0,
            title="Shutdown order — Hadapsar Industrial Estate repeat offender",
            description="Third violation in 90 days. Expired permit, no dust control measures in place.",
            latitude=18.5089,
            longitude=73.9259,
            geometry=WKTElement("POINT(73.9259 18.5089)", srid=4326),
            ai_reasoning={
                "trigger": "violation_history",
                "violation_count": 3,
                "confidence": 0.93,
            },
        ),
        EnforcementAction(
            officer_id=inspector_id or officer_id,
            source_id=source_ids[3] if len(source_ids) > 3 else None,
            ward_id="W05",
            city="Pune",
            action_type=ActionType.WARNING,
            status=ActionStatus.IN_PROGRESS,
            priority_score=61.0,
            title="Warning — Katraj waste burning detected via satellite",
            description="Biomass burning detected in W05. Contributing ~8% to area AQI. Field verification required.",
            latitude=18.4530,
            longitude=73.8618,
            geometry=WKTElement("POINT(73.8618 18.4530)", srid=4326),
            ai_reasoning={"trigger": "satellite_thermal", "confidence": 0.72},
        ),
    ]

    session.add_all(actions)
    await session.flush()
    logger.info("seed.enforcement", count=len(actions))


async def _seed_outcomes(session):
    from app.models.enforcement import InterventionOutcome

    result = await session.execute(
        select(text("id"))
        .select_from(text("enforcement_actions"))
        .where(text("status = 'completed' AND city = 'Pune'"))
        .limit(1)
    )
    action_id = result.scalar()
    if not action_id:
        return

    result2 = await session.execute(
        select(text("id"))
        .select_from(text("users"))
        .where(text("role = 'pollution_control_officer'"))
    )
    verifier_id = result2.scalar()

    outcome = InterventionOutcome(
        action_id=action_id,
        aqi_before=195.0,
        aqi_after=128.0,
        delta_score=67.0,
        pm25_before=88.5,
        pm25_after=52.3,
        measurement_period_hours=24,
        verified_by=verifier_id,
        verification_method="CAAQMS 24h rolling average comparison",
        carbon_saved_kg=240.0,
        confidence_score=0.84,
    )
    session.add(outcome)
    await session.flush()
    logger.info("seed.outcomes")


async def _seed_policy_snapshots(session):
    from app.models.analytics import PolicySnapshot

    now = datetime.now(UTC)
    policies = [
        PolicySnapshot(
            city="Pune",
            policy_type="odd_even_vehicles",
            description="Odd-even vehicle restriction on Karve Road and FC Road 7–10 AM, 5–8 PM",
            implemented_at=now - timedelta(days=45),
            impact_score=72.0,
            comparable_city_ref="Delhi",
            aqi_delta=-28.5,
            pm25_delta=-14.2,
            measurement_days=30,
            metadata={
                "coverage_roads": ["Karve Road", "FC Road"],
                "hours": "7-10, 17-20",
            },
        ),
        PolicySnapshot(
            city="Mumbai",
            policy_type="construction_dust_control",
            description="Mandatory green netting and water sprinklers for all construction sites > 500 sqm",
            implemented_at=now - timedelta(days=90),
            impact_score=58.0,
            comparable_city_ref="Pune",
            aqi_delta=-18.0,
            pm25_delta=-9.5,
            measurement_days=60,
            metadata={"compliance_rate": 0.72},
        ),
        PolicySnapshot(
            city="Delhi",
            policy_type="graded_response_action_plan",
            description="GRAP Stage III — ban on BS3 petrol and BS4 diesel vehicles",
            implemented_at=now - timedelta(days=120),
            impact_score=85.0,
            comparable_city_ref="Pune",
            aqi_delta=-45.0,
            pm25_delta=-22.0,
            measurement_days=15,
            metadata={"vehicle_categories_banned": ["BS3 petrol", "BS4 diesel"]},
        ),
    ]
    session.add_all(policies)
    await session.flush()
    logger.info("seed.policy_snapshots", count=len(policies))


async def _seed_alerts(session):
    from app.models.enforcement import CitizenAlert

    now = datetime.now(UTC)
    alerts = [
        CitizenAlert(
            ward_id="W07",
            city="Pune",
            language="mr",
            channel="push",
            risk_level="very_high",
            message_title="अत्यंत अस्वास्थ्यकर हवा — बाहेर जाणे टाळा",
            message_text="वॉर्ड W07 मध्ये AQI 285 पर्यंत पोहोचला आहे. मोकळ्या हवेत व्यायाम टाळा. श्वास घेण्यास त्रास झाल्यास त्वरित वैद्यकीय मदत घ्या.",
            vulnerability_groups_targeted=["elderly", "children", "asthma_patients"],
            aqi_value=285,
            delivery_status="sent",
            sent_at=now - timedelta(hours=1),
            ai_generated=True,
        ),
        CitizenAlert(
            ward_id="W07",
            city="Pune",
            language="en",
            channel="push",
            risk_level="very_high",
            message_title="Very Unhealthy Air — Avoid Going Outside",
            message_text="AQI in Ward W07 has reached 285 — this is harmful to everyone. Avoid outdoor exercise. Schools should consider keeping students indoors.",
            vulnerability_groups_targeted=["elderly", "children", "schools"],
            aqi_value=285,
            delivery_status="sent",
            sent_at=now - timedelta(hours=1),
            ai_generated=True,
        ),
        CitizenAlert(
            ward_id="W04",
            city="Pune",
            language="hi",
            channel="push",
            risk_level="severe",
            message_title="खतरनाक वायु गुणवत्ता — वार्ड W04 आपातकाल",
            message_text="वार्ड W04 में AQI 310 है। बाहर न जाएं। दरवाजे और खिड़कियां बंद करें।",
            vulnerability_groups_targeted=[
                "outdoor_workers",
                "industrial_area_residents",
            ],
            aqi_value=310,
            delivery_status="sent",
            sent_at=now - timedelta(hours=6),
            ai_generated=True,
        ),
    ]
    session.add_all(alerts)
    await session.flush()
    logger.info("seed.alerts", count=len(alerts))


async def _seed_alert_thresholds(session):
    """Seed default alert thresholds using CPCB (Central Pollution Control
    Board) 24-hr "Unhealthy" breakpoints as sensible starting defaults.
    Administrators can edit these from the Alert Thresholds page.
    """
    from app.models.enforcement import AlertThreshold

    # (alert_type, threshold_value, cooldown_minutes)
    defaults = [
        ("aqi", 200, 120),
        ("pm25", 90, 120),
        ("pm10", 250, 120),
        ("no2", 180, 120),
        ("co", 4, 120),
        ("o3", 168, 120),
        ("so2", 380, 120),
    ]
    thresholds = [
        AlertThreshold(
            city="Pune",
            alert_type=alert_type,
            threshold_value=value,
            cooldown_minutes=cooldown,
            is_enabled=True,
        )
        for alert_type, value, cooldown in defaults
    ]
    session.add_all(thresholds)
    await session.flush()
    logger.info("seed.alert_thresholds", count=len(thresholds))


async def _seed_ward_demographics(session):
    from app.models.demographics import WardDemographics

    # Realistic PMC figures (proportioned from city-wide ~1,900 t/day total).
    # Source: PMC Solid Waste Management Annual Report 2025-26.
    wards_data = [
        # (ward_id, generation, collection_eff, recycling, composting, landfill)
        ("W01", 210.0, 88.0, 22.0, 15.0, 58.0),  # Karve Road
        ("W02", 280.0, 92.0, 28.0, 12.0, 55.0),  # Shivajinagar
        ("W03", 260.0, 85.0, 18.0, 10.0, 65.0),  # Hadapsar
        ("W04", 320.0, 87.0, 20.0, 8.0, 68.0),  # Pimpri (industrial)
        ("W05", 195.0, 83.0, 15.0, 18.0, 62.0),  # Katraj
        ("W06", 185.0, 90.0, 25.0, 16.0, 55.0),  # Wakad
        ("W07", 240.0, 91.0, 24.0, 18.0, 52.0),  # Kothrud
        ("W08", 220.0, 86.0, 19.0, 12.0, 62.0),  # Yerawada
    ]

    # Skip wards that already have admin-entered data.
    existing = await session.execute(
        select(WardDemographics.ward_id).where(
            WardDemographics.city == "Pune",
            WardDemographics.is_deleted.is_(False),
        )
    )
    existing_wards = set(existing.scalars().all())

    records = [
        WardDemographics(
            city="Pune",
            ward_id=ward_id,
            waste_generation_tons_per_day=generation,
            waste_collection_efficiency_pct=collection_eff,
            waste_recycling_pct=recycling,
            waste_composting_pct=composting,
            waste_landfill_pct=landfill,
            waste_data_as_of=date(2026, 3, 31),
            source_note="PMC Solid Waste Management Annual Report 2025-26",
        )
        for ward_id, generation, collection_eff, recycling, composting, landfill in wards_data
        if ward_id not in existing_wards
    ]

    if records:
        session.add_all(records)
        await session.flush()
    logger.info(
        "seed.ward_demographics", count=len(records), skipped=len(existing_wards)
    )
