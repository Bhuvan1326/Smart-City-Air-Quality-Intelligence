from datetime import datetime
from uuid import UUID

from sqlalchemy import desc, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.monitoring import AQIReading, MonitoringStation, QualityFlag
from app.repositories.base import BaseRepository


class MonitoringStationRepository(BaseRepository[MonitoringStation]):
    def __init__(self, session: AsyncSession) -> None:
        super().__init__(MonitoringStation, session)

    async def get_active_by_city(self, city: str) -> list[MonitoringStation]:
        result = await self.session.execute(
            select(MonitoringStation).where(
                MonitoringStation.city == city,
                MonitoringStation.is_active.is_(True),
                MonitoringStation.is_deleted.is_(False),
            )
        )
        return list(result.scalars().all())

    async def get_by_station_code(self, code: str) -> MonitoringStation | None:
        result = await self.session.execute(
            select(MonitoringStation).where(
                MonitoringStation.station_code == code,
                MonitoringStation.is_deleted.is_(False),
            )
        )
        return result.scalar_one_or_none()

    async def get_stations_needing_maintenance(
        self, threshold: float = 0.7
    ) -> list[MonitoringStation]:
        result = await self.session.execute(
            select(MonitoringStation).where(
                MonitoringStation.maintenance_score < threshold,
                MonitoringStation.is_active.is_(True),
                MonitoringStation.is_deleted.is_(False),
            )
        )
        return list(result.scalars().all())


class AQIReadingRepository(BaseRepository[AQIReading]):
    def __init__(self, session: AsyncSession) -> None:
        super().__init__(AQIReading, session)

    async def get_latest_by_station(self, station_id: UUID) -> AQIReading | None:
        result = await self.session.execute(
            select(AQIReading)
            .where(
                AQIReading.station_id == station_id,
                AQIReading.quality_flag != QualityFlag.INVALID,
                AQIReading.is_deleted.is_(False),
            )
            .order_by(desc(AQIReading.timestamp))
            .limit(1)
        )
        return result.scalar_one_or_none()

    async def get_history(
        self,
        station_id: UUID | None,
        start_time: datetime,
        end_time: datetime,
        interval: str = "1h",
        city: str | None = None,
        ward_id: str | None = None,
    ) -> list[dict]:
        """Time-bucketed AQI history.

        Exactly one of `station_id` or `city` must be provided by the
        caller (enforced in the API layer) — this method itself still
        requires station_id XOR city to avoid silently aggregating every
        station in every city together, which was the original bug here.
        `ward_id` further narrows the city-wide query when given.
        """
        interval_map = {
            "15m": "15 minutes",
            "1h": "1 hour",
            "6h": "6 hours",
            "24h": "1 day",
        }
        pg_interval = interval_map.get(interval, "1 hour")

        if station_id:
            stmt = text(
                """
                SELECT
                    time_bucket(:interval, timestamp) AS bucket,
                    AVG(pm25) AS pm25,
                    AVG(pm10) AS pm10,
                    AVG(aqi) AS aqi,
                    AVG(no2) AS no2,
                    AVG(so2) AS so2,
                    AVG(co) AS co,
                    AVG(o3) AS o3,
                    AVG(temperature) AS temperature,
                    AVG(humidity) AS humidity,
                    COUNT(*) AS reading_count
                FROM aqi_readings
                WHERE station_id = :station_id
                  AND timestamp BETWEEN :start_time AND :end_time
                  AND is_deleted = false
                  AND quality_flag != 'invalid'
                GROUP BY bucket
                ORDER BY bucket
            """
            )
            result = await self.session.execute(
                stmt,
                {
                    "interval": pg_interval,
                    "station_id": station_id,
                    "start_time": start_time,
                    "end_time": end_time,
                },
            )
        elif city:
            ward_clause = "AND s.ward_id = :ward_id" if ward_id else ""
            stmt = text(
                f"""
                SELECT
                    time_bucket(:interval, r.timestamp) AS bucket,
                    AVG(r.pm25) AS pm25,
                    AVG(r.pm10) AS pm10,
                    AVG(r.aqi) AS aqi,
                    AVG(r.no2) AS no2,
                    AVG(r.so2) AS so2,
                    AVG(r.co) AS co,
                    AVG(r.temperature) AS temperature,
                    AVG(r.humidity) AS humidity,
                    COUNT(*) AS reading_count
                FROM aqi_readings r
                JOIN monitoring_stations s ON r.station_id = s.id
                WHERE s.city = :city
                  {ward_clause}
                  AND r.timestamp BETWEEN :start_time AND :end_time
                  AND r.is_deleted = false
                  AND r.quality_flag != 'invalid'
                GROUP BY bucket
                ORDER BY bucket
            """
            )
            # ward_clause is a fixed, code-controlled string (present or
            # absent) — never built from request input — so this f-string
            # is safe; the actual ward_id value is still bound below.
            params = {
                "interval": pg_interval,
                "city": city,
                "start_time": start_time,
                "end_time": end_time,
            }
            if ward_id:
                params["ward_id"] = ward_id
            result = await self.session.execute(stmt, params)
        else:
            raise ValueError("get_history requires either station_id or city")

        return [dict(row._mapping) for row in result]

    async def get_city_average_aqi(self, city: str) -> float | None:
        stmt = text(
            """
            SELECT AVG(r.aqi)
            FROM aqi_readings r
            JOIN monitoring_stations s ON r.station_id = s.id
            WHERE s.city = :city
              AND r.timestamp > NOW() - INTERVAL '1 hour'
              AND r.is_deleted = false
              AND r.quality_flag != 'invalid'
        """
        )
        result = await self.session.scalar(stmt, {"city": city})
        return float(result) if result is not None else None

    async def get_city_average_aqi_around(
        self, city: str, hours_ago: float, window_hours: float = 2.0
    ) -> float | None:
        """Average AQI for `city` in a window centered `hours_ago` in the past.

        Used to compute trend deltas (e.g. "now" vs "24h ago") from actual
        historical readings rather than a hard-coded placeholder.
        """
        half_window = window_hours / 2
        stmt = text(
            """
            SELECT AVG(r.aqi)
            FROM aqi_readings r
            JOIN monitoring_stations s ON r.station_id = s.id
            WHERE s.city = :city
              AND r.timestamp BETWEEN
                  NOW() - ((:hours_ago + :half_window) * INTERVAL '1 hour')
                  AND NOW() - ((:hours_ago - :half_window) * INTERVAL '1 hour')
              AND r.is_deleted = false
              AND r.quality_flag != 'invalid'
            """
        )
        result = await self.session.scalar(
            stmt,
            {"city": city, "hours_ago": hours_ago, "half_window": half_window},
        )
        return float(result) if result is not None else None

    async def get_station_trend(self, station_id: UUID, current_aqi: int | None) -> str:
        """Compare the current reading to the station's average AQI over the
        preceding ~3 hours (excluding the very latest reading) to classify
        the short-term trend.
        """
        if current_aqi is None:
            return "unavailable"

        stmt = text(
            """
            SELECT AVG(aqi)
            FROM aqi_readings
            WHERE station_id = :station_id
              AND is_deleted = false
              AND quality_flag != 'invalid'
              AND timestamp BETWEEN NOW() - INTERVAL '4 hours' AND NOW() - INTERVAL '30 minutes'
            """
        )
        result = await self.session.scalar(stmt, {"station_id": station_id})
        if result is None:
            return "unavailable"

        prior_avg = float(result)
        delta = current_aqi - prior_avg
        # A small dead-band avoids labelling normal noise as a trend.
        if abs(delta) < max(3.0, prior_avg * 0.05):
            return "stable"
        return "increasing" if delta > 0 else "decreasing"

    async def get_ward_aqi_snapshot(self, city: str) -> list[dict]:
        stmt = text(
            """
            SELECT
                s.ward_id,
                AVG(r.aqi) AS avg_aqi,
                MAX(r.aqi) AS max_aqi,
                AVG(r.pm25) AS avg_pm25,
                COUNT(DISTINCT s.id) AS station_count,
                MAX(r.timestamp) AS last_reading
            FROM aqi_readings r
            JOIN monitoring_stations s ON r.station_id = s.id
            WHERE s.city = :city
              AND r.timestamp > NOW() - INTERVAL '1 hour'
              AND r.is_deleted = false
              AND r.quality_flag != 'invalid'
              AND s.ward_id IS NOT NULL
            GROUP BY s.ward_id
            ORDER BY avg_aqi DESC
        """
        )
        result = await self.session.execute(stmt, {"city": city})
        return [dict(row._mapping) for row in result]
