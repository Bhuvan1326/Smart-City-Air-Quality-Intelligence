"""India AQI Intelligence — query service layer.

Backs GET /api/v1/aqi/india and GET /api/v1/aqi/india/states. Thin
orchestration layer over the *existing* MonitoringStationRepository /
AQIReadingRepository — no new SQL beyond
`MonitoringStationRepository.search_by_geography`/`distinct_states`, and
reuses `AQIReadingRepository.get_latest_by_station` (already used by
GET /aqi/live) for the "latest reading per station" lookup.

Scope: this module *queries* whatever OpenAQ-discovered India station data
exists in the database (station_type="OpenAQ", see
`MonitoringStationRepository.search_by_geography`) — populated by
`app.workers.tasks.aqi_ingestion.discover_and_ingest_india_locations`. The
separate six-station Pune/Mumbai CAAQMS fixtures also carry country="India"
but are excluded here (and from the heatmap) since they belong to the
unrelated city-scoped Live AQI feature, not this India-wide dataset. This
module has no ingestion logic of its own — it only ever reflects the
database, so coverage grows automatically as ingestion runs, never padded
with fabricated placeholder rows.

Known limitation (documented, not hidden): `category` and `source` filters
depend on each station's *latest reading*, which isn't a queryable column
on MonitoringStation. Pagination happens at the station-query level
(bounded, indexed, safe) and category/source filtering is applied to that
page's results afterward — so `total` reflects station-level filters
(country/state/city/bbox) only. Accurate today given the current dataset
size; revisit (e.g. denormalize latest-AQI/category onto the station row)
once India-wide ingestion makes the station count large enough to matter.
"""

from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy.ext.asyncio import AsyncSession

from app.models.monitoring import MonitoringStation, QualityFlag
from app.repositories.aqi import AQIReadingRepository, MonitoringStationRepository
from app.schemas.aqi import (
    IndiaAQIObservationResponse,
    get_aqi_category,
    get_aqi_method,
    resolve_data_source,
)
from app.services.data_freshness import classify_freshness

INDIA_COUNTRY = "India"

VALID_AQI_CATEGORIES = {
    "good",
    "moderate",
    "unhealthy for sensitive groups",
    "unhealthy",
    "very unhealthy",
    "hazardous",
}

VALID_DATA_SOURCES = {"openaq"}


class InvalidIndiaAQIFilterError(ValueError):
    """Raised for a filter combination the endpoint should reject with a
    400, as opposed to an unexpected/internal error."""


@dataclass(frozen=True)
class IndiaAQIFilters:
    state: str | None = None
    city: str | None = None
    category: str | None = None
    source: str | None = None
    min_lat: float | None = None
    min_lon: float | None = None
    max_lat: float | None = None
    max_lon: float | None = None
    page: int = 1
    page_size: int = 50

    def __post_init__(self) -> None:
        if self.page < 1:
            raise InvalidIndiaAQIFilterError("page must be >= 1")
        if not (1 <= self.page_size <= 200):
            raise InvalidIndiaAQIFilterError("limit must be between 1 and 200")

        if (
            self.category is not None
            and self.category.lower() not in VALID_AQI_CATEGORIES
        ):
            raise InvalidIndiaAQIFilterError(
                f"Unknown category '{self.category}'. Valid values: "
                f"{sorted(VALID_AQI_CATEGORIES)}"
            )
        if self.source is not None and self.source.lower() not in VALID_DATA_SOURCES:
            raise InvalidIndiaAQIFilterError(
                f"Unknown source '{self.source}'. Valid values: "
                f"{sorted(VALID_DATA_SOURCES)}"
            )

        bbox_fields = (self.min_lat, self.min_lon, self.max_lat, self.max_lon)
        bbox_provided = [f is not None for f in bbox_fields]
        if any(bbox_provided) and not all(bbox_provided):
            raise InvalidIndiaAQIFilterError(
                "bbox requires all four of min_lat, min_lon, max_lat, max_lon"
            )
        if all(bbox_provided):
            if not (-90 <= self.min_lat <= 90) or not (-90 <= self.max_lat <= 90):
                raise InvalidIndiaAQIFilterError("Latitude must be between -90 and 90")
            if not (-180 <= self.min_lon <= 180) or not (-180 <= self.max_lon <= 180):
                raise InvalidIndiaAQIFilterError(
                    "Longitude must be between -180 and 180"
                )
            if self.min_lat > self.max_lat:
                raise InvalidIndiaAQIFilterError("min_lat must be <= max_lat")
            if self.min_lon > self.max_lon:
                raise InvalidIndiaAQIFilterError("min_lon must be <= max_lon")


async def _build_observation(
    station: MonitoringStation, reading
) -> IndiaAQIObservationResponse:
    """Build the response record for one station, whether or not it has
    an accepted observation. A station with `reading is None` is still
    returned — never dropped — with every reading-derived field None and
    `freshness="unavailable"`, so the frontend can render it honestly
    instead of the station silently disappearing or showing AQI 0.
    """
    if reading is None:
        return IndiaAQIObservationResponse(
            station_id=station.id,
            station_name=station.name,
            station_code=station.station_code,
            station_type=station.station_type,
            openaq_location_id=station.openaq_location_id,
            city=station.city,
            state=station.state,
            country=station.country,
            latitude=station.latitude,
            longitude=station.longitude,
            aqi=None,
            aqi_category=None,
            aqi_method=None,
            pm25=None,
            pm10=None,
            no2=None,
            so2=None,
            co=None,
            o3=None,
            observed_at=None,
            fetched_at=None,
            data_source=None,
            quality_flag=None,
            freshness=classify_freshness(None).value,
        )

    category = get_aqi_category(reading.aqi)[0] if reading.aqi is not None else None
    is_synthetic = reading.quality_flag == QualityFlag.SYNTHETIC
    freshness = classify_freshness(reading.timestamp, is_synthetic=is_synthetic)

    return IndiaAQIObservationResponse(
        station_id=station.id,
        station_name=station.name,
        station_code=station.station_code,
        station_type=station.station_type,
        openaq_location_id=station.openaq_location_id,
        city=station.city,
        state=station.state,
        country=station.country,
        latitude=station.latitude,
        longitude=station.longitude,
        aqi=reading.aqi,
        aqi_category=category,
        aqi_method=get_aqi_method(reading.aqi, reading.pm25),
        pm25=reading.pm25,
        pm10=reading.pm10,
        no2=reading.no2,
        so2=reading.so2,
        co=reading.co,
        o3=reading.o3,
        observed_at=reading.timestamp,
        # AQIReading.created_at (TimestampMixin) is when this platform
        # persisted the reading — exactly "fetched_at". Reused rather than
        # adding a duplicate column.
        fetched_at=reading.created_at,
        data_source=resolve_data_source(reading.quality_flag),
        quality_flag=QualityFlag(reading.quality_flag),
        freshness=freshness.value,
    )


async def get_india_aqi_observations(
    session: AsyncSession, filters: IndiaAQIFilters
) -> tuple[list[IndiaAQIObservationResponse], int]:
    """Returns (observations, total) for the given filters.

    `total` counts stations matching the geography filters (country/state/
    city/bbox) — see the module docstring's "known limitation" note
    regarding category/source filtering happening after this count.

    Every station matching the geography filters is returned, whether or
    not it currently has an accepted observation — a station is never
    dropped merely for lacking a reading (see `_build_observation`).
    """
    station_repo = MonitoringStationRepository(session)
    reading_repo = AQIReadingRepository(session)

    stations, total = await station_repo.search_by_geography(
        country=INDIA_COUNTRY,
        state=filters.state,
        city=filters.city,
        min_lat=filters.min_lat,
        min_lon=filters.min_lon,
        max_lat=filters.max_lat,
        max_lon=filters.max_lon,
        skip=(filters.page - 1) * filters.page_size,
        limit=filters.page_size,
    )

    # One batched latest-reading query for the whole page instead of one
    # round-trip per station.
    readings_by_station = await reading_repo.get_latest_by_stations(
        [station.id for station in stations]
    )

    observations: list[IndiaAQIObservationResponse] = []
    for station in stations:
        reading = readings_by_station.get(station.id)
        obs = await _build_observation(station, reading)

        if filters.category is not None and (
            obs.aqi_category is None
            or obs.aqi_category.lower() != filters.category.lower()
        ):
            continue
        if (
            filters.source is not None
            and (obs.data_source or "").lower() != filters.source.lower()
        ):
            continue

        observations.append(obs)

    return observations, total


async def get_india_states(session: AsyncSession) -> list[str]:
    """Distinct states actually present among India-tagged stations —
    backs GET /api/v1/aqi/india/states. Always the real database contents,
    never a static/invented list of India's states.
    """
    station_repo = MonitoringStationRepository(session)
    return await station_repo.distinct_states(country=INDIA_COUNTRY)


async def get_india_aqi_heatmap_observations(
    session: AsyncSession,
) -> list[IndiaAQIObservationResponse]:
    """Same canonical India OpenAQ dataset as `get_india_aqi_observations`
    (via `MonitoringStationRepository.get_india_heatmap_observations`),
    used by both the India AQI list and the heatmap so the two views can
    never drift apart. A station with no observation is still included —
    with `aqi=None` and `freshness="unavailable"` — so the frontend can
    render it as a neutral/unavailable marker; it must never be folded
    into AQI intensity as if it were 0.
    """
    station_repo = MonitoringStationRepository(session)
    pairs = await station_repo.get_india_heatmap_observations()
    observations: list[IndiaAQIObservationResponse] = []
    for station, reading in pairs:
        observations.append(await _build_observation(station, reading))
    return observations
